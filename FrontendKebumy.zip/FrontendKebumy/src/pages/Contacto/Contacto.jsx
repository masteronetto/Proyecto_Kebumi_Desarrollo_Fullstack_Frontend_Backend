
import { Navbar } from '../../components/Navbar/Navbar'; 
import { Footer } from '../../components/Footer/Footer';
import './Contacto.css';

// Importa las imágenes estáticas necesarias
import logoGatoEmocionado from '../../assets/Logo_GatoEmocionado.png';
import logoIG from '../../assets/Logo ig.png';
import logoCorreo from '../../assets/Logo correo.png';
import logoFacebook from '../../assets/Logo facebook.png';
import logoWSP from '../../assets/Logo_WSP.png';

export default function Contacto() {
    return (
        <div className="para-ti-page"> 
            <Navbar /> 

            <main className="para-ti-page main">
                <div className="para-ti-container">
                    <div className="para-ti-content">
                        <div className="para-ti-text">
                            <h2 className="para-ti-title">¡Estamos aquí para ti!</h2>
                            <p className="para-ti-description">
                                Sabemos que los detalles marcan la diferencia. Por eso, en Kebumy te invitamos a contarnos tu idea. Juntos crearemos un diseño único que refleje lo especial que quieres transmitir.
                            </p>
                        </div>
                        <div className="para-ti-image">
                            <img src={logoGatoEmocionado} alt="Gato emocionado de Kebumy" />
                        </div>
                    </div>

                    <div className="contacto-proyecto">
                        <h3 className="proyecto-title">Hablemos de tu proyecto</h3>
                        <div className="contacto-info-grid">
                            <a href="https://instagram.com/kebumy" target="_blank" rel="noopener noreferrer" className="contacto-item contacto-link">
                                <img src={logoIG} alt="Logo Instagram" className="contacto-icon" />
                                <span className="contacto-text">@kebumy</span>
                            </a>
                            <a href="mailto:kebumy.cliente@gmail.com" className="contacto-item contacto-link">
                                <img src={logoCorreo} alt="Logo Email" className="contacto-icon" />
                                <span className="contacto-text">kebumy.cliente@gmail.com</span>
                            </a>
                            <a href="https://facebook.com/kebumy" target="_blank" rel="noopener noreferrer" className="contacto-item contacto-link">
                                <img src={logoFacebook} alt="Logo Facebook" className="contacto-icon" />
                                <span className="contacto-text">kebumy</span>
                            </a>
                            <a href="https://wa.me/56912345678" target="_blank" rel="noopener noreferrer" className="contacto-item contacto-link">
                                <img src={logoWSP} alt="Logo WhatsApp" className="contacto-icon" />
                                <span className="contacto-text">+56 9 1234 5678</span>
                            </a>
                        </div>
                    </div>
                </div>
            </main>

            <Footer />
        </div>
    );
}
