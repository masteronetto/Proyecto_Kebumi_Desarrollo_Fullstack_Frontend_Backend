import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import apiService from '../../services/apiService';
import EditarUsuario from './EditarUsuario';

export function Usuarios() {
    const [usuarios, setUsuarios] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [editModalOpen, setEditModalOpen] = useState(false);
    const [usuarioParaEditar, setUsuarioParaEditar] = useState(null);

    const fetchUsuarios = async () => {
        setLoading(true);
        setError(null);
        try {
            const data = await apiService.getUsuarios();
            setUsuarios(data);
        } catch (error) {
            console.error('Error al cargar usuarios:', error);
            setError(error.message || 'No se pudo cargar la lista de usuarios.');
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchUsuarios();
    }, []);

    const handleDelete = async (id) => {
        if (!window.confirm(`¿Está seguro de INHABILITAR al usuario ID: ${id}?`)) return;
        try {
            await apiService.deleteUsuario(id);
            await fetchUsuarios(); // Recargar la lista
            alert('Usuario inhabilitado correctamente');
        } catch (error) {
            console.error('Error al inhabilitar usuario:', error);
            alert('Error al inhabilitar el usuario: ' + error.message);
        }
    };

    const handleEdit = (usuario) => {
        console.log('📝 Abriendo modal de edición para usuario:', usuario);
        setUsuarioParaEditar(usuario);
        setEditModalOpen(true);
    };

    const handleCloseEditModal = () => {
        setEditModalOpen(false);
        setUsuarioParaEditar(null);
    };

    const handleUsuarioActualizado = () => {
        fetchUsuarios(); // Recargar la lista después de actualizar
    };

    const getStatusClass = (estado) => {
        return estado && estado.toLowerCase() === 'activo' ? 'status-active' : 'status-inactive';
    };

    if (loading) return (
        <div style={{ textAlign: 'center', padding: '40px' }}>
            <p style={{ color: '#555', fontSize: '1.2em' }}>Cargando usuarios...</p>
        </div>
    );
    
    if (error) return (
        <div style={{ 
            backgroundColor: '#f8d7da', 
            color: '#721c24', 
            padding: '20px', 
            borderRadius: '5px', 
            margin: '20px 0',
            border: '1px solid #f5c6cb'
        }}>
            {error}
        </div>
    );

    return (
        <div className="users-widgets-grid">
            {/* Widget de total de usuarios */}
            <div className="total-users">
                <div className="user-info-text">
                    <div className="widget-title">Total de Usuarios</div>
                    <div className="widget-number">{usuarios.length}</div>
                </div>
                <img src="/src/assets/Logo_GatoEmocionado.png" alt="Usuarios" className="widget-icon-user" />
            </div>
            
            {/* Tabla de usuarios */}
            <div className="users-table-container">
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
                    <div className="widget-title" style={{ backgroundColor: '#b0417a', color: 'white', padding: '10px', borderRadius: '8px', textAlign: 'center', margin: 0 }}>
                        Gestión de Usuarios
                    </div>
                    <Link 
                        to="/crear-usuario"
                        style={{
                            backgroundColor: '#b0417a',
                            color: 'white',
                            padding: '10px 20px',
                            borderRadius: '20px',
                            textDecoration: 'none',
                            fontSize: '0.9em'
                        }}
                    >
                        + Crear Usuario
                    </Link>
                </div>
                
                <div className="table-scroll-wrapper">
                    <table className="orders-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nombre</th>
                                <th>Email</th>
                                <th>Rol</th>
                                <th>Estado</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            {usuarios.length === 0 ? (
                                <tr>
                                    <td colSpan="6" style={{ textAlign: 'center', padding: '20px', color: '#888' }}>
                                        No hay usuarios registrados.
                                    </td>
                                </tr>
                            ) : (
                                usuarios.map(usuario => (
                                    <tr key={usuario.id}>
                                        <td>{usuario.id}</td>
                                        <td>{usuario.nombre}</td>
                                        <td>{usuario.email}</td>
                                        <td>{usuario.rol}</td>
                                        <td className={getStatusClass(usuario.estado)}>{usuario.estado}</td>
                                        <td>
                                            <div style={{ display: 'flex', gap: '5px' }}>
                                                <button 
                                                    className="action-btn"
                                                    title="Editar usuario"
                                                    onClick={() => handleEdit(usuario)}
                                                >
                                                    ✏️
                                                </button>
                                                <button 
                                                    className="action-btn delete-btn"
                                                    title="Inhabilitar usuario"
                                                    onClick={() => handleDelete(usuario.id)}
                                                >
                                                    🗑️
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                ))
                            )}
                        </tbody>
                    </table>
                </div>
                
                {usuarios.length === 0 && (
                    <div style={{ 
                        textAlign: 'center', 
                        padding: '40px',
                        backgroundColor: '#f0f0f0',
                        borderRadius: '8px',
                        margin: '20px 0'
                    }}>
                        <p style={{ color: '#555', fontSize: '1.1em' }}>
                            No hay usuarios registrados en el sistema.
                        </p>
                        <Link 
                            to="/crear-usuario"
                            style={{
                                backgroundColor: '#925c93',
                                color: 'white',
                                padding: '12px 30px',
                                borderRadius: '20px',
                                textDecoration: 'none',
                                fontSize: '1em'
                            }}
                        >
                            Crear primer usuario
                        </Link>
                    </div>
                )}
            </div>

            {/* Modal de edición */}
            <EditarUsuario
                usuario={usuarioParaEditar}
                isOpen={editModalOpen}
                onClose={handleCloseEditModal}
                onUsuarioActualizado={handleUsuarioActualizado}
            />
        </div>
    );
}