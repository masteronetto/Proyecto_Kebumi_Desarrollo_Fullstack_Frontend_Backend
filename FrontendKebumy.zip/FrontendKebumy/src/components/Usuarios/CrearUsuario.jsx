// src/components/Usuarios/CrearUsuario.jsx
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Navbar } from '../Navbar/Navbar';
import apiService from '../../services/apiService';

export default function CrearUsuario() {
    const navigate = useNavigate();
    const [user, setUser] = useState({
        nombre: '',
        email: '',
        password: '',
        rol: 'cliente', // Valor por defecto
        estado: 'activo'
    });
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setUser(prev => ({
            ...prev,
            [name]: value,
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        setError(null);

        try {
            console.log('👤 Creando nuevo usuario:', user);
            
            // Usar el apiService en lugar de fetch directo
            const nuevoUsuario = await apiService.createUsuario(user);
            
            console.log('✅ Usuario creado exitosamente:', nuevoUsuario);
            
            // Mostrar confirmación
            alert('Usuario creado exitosamente');
            
            // Navegar de vuelta a la lista de usuarios
            navigate('/admin-usuarios');
            
        } catch (err) {
            console.error('❌ Error al crear usuario:', err);
            setError(err.message || 'Error al crear el usuario. Inténtelo de nuevo.');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="container">
            <Navbar />
            <h3 style={{ marginTop: '20px' }}>Crear Nuevo Usuario</h3>
            
            {error && <div className="alert alert-danger mt-3">{error}</div>}
            
            <form onSubmit={handleSubmit} className="mt-4">
                
                <div className="mb-3">
                    <label className="form-label">Nombre</label>
                    <input type="text" className="form-control" name="nombre" value={user.nombre} onChange={handleChange} required />
                </div>
                
                <div className="mb-3">
                    <label className="form-label">Email</label>
                    <input type="email" className="form-control" name="email" value={user.email} onChange={handleChange} required />
                </div>
                
                <div className="mb-3">
                    <label className="form-label">Contraseña</label>
                    <input type="password" className="form-control" name="password" value={user.password} onChange={handleChange} required />
                </div>
                
                <div className="mb-3">
                    <label className="form-label">Rol</label>
                    <select className="form-select" name="rol" value={user.rol} onChange={handleChange}>
                        <option value="cliente">Cliente</option>
                        <option value="vendedor">Vendedor</option>
                        <option value="super-admin">Super Administrador</option>
                    </select>
                </div>
                
                <button type="submit" className="btn btn-success" disabled={loading}>
                    {loading ? 'Guardando...' : 'Crear Usuario'}
                </button>
            </form>
        </div>
    );
}