// src/components/DiagnosticTool/DiagnosticTool.jsx
// Herramienta de diagnóstico para problemas de conexión

import React, { useState } from 'react';
import { API_CONFIG } from '../../config/api';

export function DiagnosticTool() {
    const [results, setResults] = useState([]);
    const [testing, setTesting] = useState(false);

    const addResult = (step, status, message, details = null) => {
        const result = {
            step,
            status, // 'success', 'error', 'info'
            message,
            details,
            timestamp: new Date().toLocaleTimeString()
        };
        setResults(prev => [...prev, result]);
        console.log(`[${step}] ${status.toUpperCase()}: ${message}`, details || '');
    };

    const runDiagnostic = async () => {
        setTesting(true);
        setResults([]);

        try {
            addResult('1. CONFIGURACIÓN', 'info', 'Verificando configuración actual');
            addResult('1.1', 'info', `Health Check URL: ${API_CONFIG.HEALTH_CHECK_URL}`);
            addResult('1.2', 'info', `Backend URL: ${API_CONFIG.BASE_URL}`);
            addResult('1.3', 'info', `Frontend URL: ${window.location.origin}`);

            // Test 1: Health Check
            addResult('2. HEALTH CHECK', 'info', 'Probando conexión con health check...');
            try {
                const healthResponse = await fetch(API_CONFIG.HEALTH_CHECK_URL, {
                    method: 'GET',
                    headers: { 'Accept': 'application/json' },
                    mode: 'cors'
                });

                if (healthResponse.ok) {
                    const healthData = await healthResponse.json();
                    addResult('2.1', 'success', 'Health check exitoso', healthData);
                } else {
                    addResult('2.1', 'error', `Health check falló: ${healthResponse.status}`);
                }
            } catch (error) {
                addResult('2.1', 'error', 'Health check error', error.message);
            }

            // Test 2: Backend API Endpoints
            addResult('3. BACKEND API', 'info', 'Probando endpoints del backend...');
            
            // Test usuarios
            try {
                const usuariosResponse = await fetch(`${API_CONFIG.BASE_URL}/usuarios`, {
                    method: 'GET',
                    headers: { 'Accept': 'application/json' },
                    mode: 'cors'
                });

                addResult('3.1', usuariosResponse.ok ? 'success' : 'error', 
                    `Endpoint /usuarios: ${usuariosResponse.status}`, 
                    [...usuariosResponse.headers.entries()]);
            } catch (error) {
                addResult('3.1', 'error', 'Endpoint /usuarios error', error.message);
            }

            // Test productos
            try {
                const productosResponse = await fetch(`${API_CONFIG.BASE_URL}/productos`, {
                    method: 'GET',
                    headers: { 'Accept': 'application/json' },
                    mode: 'cors'
                });

                addResult('3.2', productosResponse.ok ? 'success' : 'error', 
                    `Endpoint /productos: ${productosResponse.status}`);
            } catch (error) {
                addResult('3.2', 'error', 'Endpoint /productos error', error.message);
            }

            // Test 3: Login Endpoint (CORREGIDO)
            addResult('4. LOGIN ENDPOINT', 'info', 'Probando endpoint de login...');
            try {
                const loginResponse = await fetch(`${API_CONFIG.BASE_URL}${API_CONFIG.ENDPOINTS.LOGIN}`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    },
                    mode: 'cors',
                    body: JSON.stringify({
                        email: 'test@test.com',
                        password: 'test'
                    })
                });

                addResult('4.1', 'info', 
                    `Login endpoint responde: ${loginResponse.status}`, 
                    `Headers: ${[...loginResponse.headers.entries()].map(([k,v]) => `${k}: ${v}`).join(', ')}`);
            } catch (error) {
                addResult('4.1', 'error', 'Login endpoint error', error.message);
            }

            addResult('5. DIAGNÓSTICO', 'success', 'Diagnóstico completado');

        } catch (error) {
            addResult('ERROR', 'error', 'Error general en diagnóstico', error.message);
        } finally {
            setTesting(false);
        }
    };

    const getStatusColor = (status) => {
        switch (status) {
            case 'success': return '#4CAF50';
            case 'error': return '#F44336';
            case 'info': return '#2196F3';
            default: return '#666';
        }
    };

    return (
        <div style={{
            position: 'fixed',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
            backgroundColor: 'white',
            border: '2px solid #b0417a',
            borderRadius: '8px',
            padding: '20px',
            maxWidth: '600px',
            maxHeight: '80vh',
            overflow: 'auto',
            zIndex: 2000,
            boxShadow: '0 8px 32px rgba(0,0,0,0.3)'
        }}>
            <div style={{ marginBottom: '20px', textAlign: 'center' }}>
                <h3 style={{ color: '#b0417a', margin: 0 }}>🔧 Diagnóstico de Conexión</h3>
                <p style={{ margin: '10px 0', fontSize: '14px', color: '#666' }}>
                    Esta herramienta verifica la conectividad con tu backend
                </p>
            </div>

            <div style={{ marginBottom: '20px', textAlign: 'center' }}>
                <button
                    onClick={runDiagnostic}
                    disabled={testing}
                    style={{
                        backgroundColor: testing ? '#ccc' : '#b0417a',
                        color: 'white',
                        border: 'none',
                        padding: '10px 20px',
                        borderRadius: '5px',
                        cursor: testing ? 'not-allowed' : 'pointer',
                        marginRight: '10px'
                    }}
                >
                    {testing ? 'Ejecutando...' : '🚀 Ejecutar Diagnóstico'}
                </button>

                <button
                    onClick={() => setResults([])}
                    style={{
                        backgroundColor: '#925c93',
                        color: 'white',
                        border: 'none',
                        padding: '10px 20px',
                        borderRadius: '5px',
                        cursor: 'pointer'
                    }}
                >
                    🗑️ Limpiar
                </button>
            </div>

            <div style={{ maxHeight: '400px', overflow: 'auto' }}>
                {results.map((result, index) => (
                    <div key={index} style={{
                        marginBottom: '10px',
                        padding: '8px',
                        backgroundColor: '#f5f5f5',
                        borderRadius: '4px',
                        borderLeft: `4px solid ${getStatusColor(result.status)}`
                    }}>
                        <div style={{ 
                            fontSize: '12px', 
                            color: getStatusColor(result.status),
                            fontWeight: 'bold'
                        }}>
                            [{result.timestamp}] {result.step}
                        </div>
                        <div style={{ fontSize: '14px', marginTop: '4px' }}>
                            {result.message}
                        </div>
                        {result.details && (
                            <div style={{ 
                                fontSize: '12px', 
                                color: '#666', 
                                marginTop: '4px',
                                fontFamily: 'monospace',
                                backgroundColor: '#fff',
                                padding: '4px',
                                borderRadius: '2px'
                            }}>
                                {typeof result.details === 'object' 
                                    ? JSON.stringify(result.details, null, 2)
                                    : result.details}
                            </div>
                        )}
                    </div>
                ))}
            </div>

            {results.length === 0 && !testing && (
                <div style={{ textAlign: 'center', color: '#666', fontStyle: 'italic' }}>
                    Haz clic en "Ejecutar Diagnóstico" para comenzar
                </div>
            )}
        </div>
    );
}

export default DiagnosticTool;