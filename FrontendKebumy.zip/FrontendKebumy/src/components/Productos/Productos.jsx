import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import apiService from '../../services/apiService';
import { ApiService } from '../../services/apiService';
import EditarProducto from './EditarProducto';

// Importar todas las imágenes necesarias
import PolerImg from '../../assets/Polera.png';
import PoleronImg from '../../assets/Poleron.png';
import AgendaImg from '../../assets/Agenda.png';
import StickerImg from '../../assets/sticker.png';
import PolaroidImg from '../../assets/Polaroid.png';
import MiniCalendarioImg from '../../assets/miniCalendario.png';
import PolerasMarcaImg from '../../assets/PolerasMarca.png';
import TarjetaPresentacionImg from '../../assets/TarjetaPresentacion2.jpeg';
import EtiquetaCueroImg from '../../assets/etiquetaCuero.png';
import Sticker3Img from '../../assets/Sticker3.png';
import KitCumpleanosImg from '../../assets/KitCumpleaños.png';
import ImagenProducto1 from '../../assets/imagen producto 1.webp';
import ImagenProducto2 from '../../assets/polaroid2.avif';

// ===============================
// 🖼️ SISTEMA ROBUSTO DE IMÁGENES
// ===============================
const getImageUrl = (producto) => {
    const productName = producto.nombre || 'Sin nombre';
    const imagenUrl = producto.imagen_url;
    
    // Mapeo de imágenes locales importadas
    const imageMap = {
        'img/Polera.png': PolerImg,
        'img/Poleron.png': PoleronImg,
        'img/Agenda.png': AgendaImg,
        'img/sticker.png': StickerImg,
        'img/Polaroid.png': PolaroidImg,
        'img/miniCalendario.png': MiniCalendarioImg,
        'img/PolerasMarca.png': PolerasMarcaImg,
        'img/tarjetaPresentacion.png': TarjetaPresentacionImg,
        'img/etiquetaCuero.png': EtiquetaCueroImg,
        'img/stickerMarca.png': Sticker3Img,
        'img/Mochila.png': KitCumpleanosImg
    };
    
    console.log(`🖼️ [SISTEMA ROBUSTO] Procesando imagen para "${productName}" (ID: ${producto.id})`);
    console.log('📋 Datos de entrada:', {
        imagen_url: imagenUrl,
        tipo: typeof imagenUrl,
        valor_exacto: JSON.stringify(imagenUrl),
        tiene_imagenUrl: !!producto.imagenUrl,
        imagenUrl_valor: producto.imagenUrl,
        id: producto.id,
        nombre: producto.nombre
    });

    // 🔍 PASO 1: Verificar cache primero
    const cachedUrl = ApiService.getProductImage(producto.id);
    if (cachedUrl) {
        console.log(`💾 URL recuperada del cache para "${productName}": ${cachedUrl}`);
        
        // Si es una imagen base64 (imagen local)
        if (cachedUrl.startsWith('data:image/')) {
            console.log('📦 Imagen local base64 encontrada en cache');
            return cachedUrl;
        }
        
        // Si es una URL de archivo subido, construir la URL correcta del backend
        if (cachedUrl.startsWith('uploaded/')) {
          const backendUrl = `http://localhost:3000/${cachedUrl}`;
          console.log(`🔄 Convirtiendo URL de archivo subido: ${cachedUrl} → ${backendUrl}`);
          return backendUrl;
        }
        
        // URL externa normal
        return cachedUrl;
    }
    
    // 🔍 PASO 2: Buscar URL válida en diferentes campos
    let urlValida = null;
    
    // Verificar imagen_url principal
    if (imagenUrl && 
        imagenUrl !== 'undefined' && 
        imagenUrl !== 'null' && 
        typeof imagenUrl === 'string' &&
        imagenUrl.trim() !== '') {
        urlValida = imagenUrl;
    }
    
    // Si no es válida, buscar en otros campos
    if (!urlValida) {
        const camposPosibles = [
            producto.imagenUrl,
            producto.image_url,
            producto.imageUrl,
            producto.imagen,
            producto.image,
            producto.url_imagen,
            producto.foto_url
        ];
        
        for (const campo of camposPosibles) {
            if (campo && 
                campo !== 'undefined' && 
                campo !== 'null' && 
                typeof campo === 'string' &&
                campo.trim() !== '') {
                console.log(`🎯 URL válida encontrada en campo alternativo:`, campo);
                urlValida = campo;
                break;
            }
        }
    }
    
    // 🔍 PASO 3: Procesar URL válida si la encontramos
    if (urlValida) {
        // URL absoluta (externa)
        if (urlValida.startsWith('http://') || urlValida.startsWith('https://')) {
            console.log('✅ URL absoluta detectada, usando directamente');
            // Guardar en cache para persistencia
            ApiService.setProductImage(producto.id, urlValida);
            return urlValida;
        }
        
        // Imagen local (img/...)
        if (urlValida.startsWith('img/')) {
            const mappedImage = imageMap[urlValida];
            if (mappedImage) {
                console.log(`✅ Mapeando imagen: ${urlValida} → imagen importada`);
                return mappedImage;
            } else {
                console.log(`⚠️ Imagen no encontrada en mapa: ${urlValida}`);
            }
        }
        
        // Si es una imagen base64 directamente guardada en BD
        if (urlValida.startsWith('data:image/')) {
            console.log('📦 Imagen base64 detectada en imagen_url');
            return urlValida;
        }
        
        // Archivo subido (uploaded/...)
        if (urlValida.startsWith('uploaded/') || urlValida.startsWith('uploads/')) {
            console.log('📁 URL de archivo subido detectada');
            const backendUrl = `http://localhost:3000/${urlValida}`;
            console.log(`🔄 Construyendo URL del backend: ${urlValida} → ${backendUrl}`);
            return backendUrl;
        }
    }
    
    // 🔍 PASO 4: Mapeo inteligente como fallback
    console.log('⚠️ No hay imagen_url válida, intentando mapeo inteligente...');
    
    const productLower = productName.toLowerCase();
    const smartMap = {
        'polera': PolerImg,
        'poleron': PoleronImg,
        'agenda': AgendaImg,
        'libreta': AgendaImg,
        'cuaderno': AgendaImg,
        'sticker': StickerImg,
        'adhesivo': StickerImg,
        'vinilo': StickerImg,
        'polaroid': PolaroidImg,
        'foto': PolaroidImg,
        'fotografia': PolaroidImg,
        'calendario': MiniCalendarioImg,
        'imantado': MiniCalendarioImg,
        'tarjeta': TarjetaPresentacionImg,
        'presentacion': TarjetaPresentacionImg,
        'business': TarjetaPresentacionImg,
        'etiqueta': EtiquetaCueroImg,
        'cuero': EtiquetaCueroImg,
        'mochila': KitCumpleanosImg,
        'kit': KitCumpleanosImg,
        'cumpleanos': KitCumpleanosImg
    };
    
    for (const [keyword, image] of Object.entries(smartMap)) {
        if (productLower.includes(keyword)) {
            console.log(`✅ Mapeo inteligente encontrado: "${keyword}" → imagen correspondiente`);
            return image;
        }
    }
    
    // 🔍 PASO 5: Imagen por defecto
    console.log('⚠️ No se encontró mapeo inteligente, usando imagen por defecto');
    return ImagenProducto1;
};

const Productos = () => {
    const [productos, setProductos] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [productoEditando, setProductoEditando] = useState(null);
    const [mostrarModalEditar, setMostrarModalEditar] = useState(false);

    const fetchProductos = async () => {
        try {
            console.log('🔍 Fetching productos...');
            console.log('🔧 Estado del apiService:', {
                useRealBackend: apiService.useRealBackend,
                baseURL: apiService.baseURL
            });
            
            const productosData = await apiService.getProductos();
            console.log('✅ Productos obtenidos:', productosData);
            setProductos(productosData);
            
            // Log detallado del primer producto
            if (productosData.length > 0) {
                console.log('🔍 Ejemplo de producto recibido:', {
                    ...productosData[0],
                    tipo_imagen_url: typeof productosData[0].imagen_url,
                    estructura_completa: Object.keys(productosData[0])
                });
            }
            
            // 🔍 ANÁLISIS DETALLADO DE IMÁGENES
            console.log('\n🔍 ANÁLISIS DE IMÁGENES EN TODOS LOS PRODUCTOS:');
            let productosProblematicos = [];
            
            productosData.forEach((producto, index) => {
                console.log(`\n--- PRODUCTO ${index + 1}: "${producto.nombre}" ---`);
                console.log(`🖼️ imagen_url: "${producto.imagen_url}" (${typeof producto.imagen_url})`);
                
                // Análisis de campos de imagen disponibles
                const camposImagen = {};
                ['imagenUrl', 'imagen_url', 'image_url', 'imageUrl', 'imagen', 'image'].forEach(campo => {
                    if (producto[campo] !== undefined) {
                        camposImagen[campo] = producto[campo];
                    }
                });
                console.log('📂 Campos de imagen encontrados:', camposImagen);
                
                // Análisis detallado del estado de imagen_url
                const estadoImagen = {
                    esUndefined: producto.imagen_url === undefined,
                    esNull: producto.imagen_url === null,
                    esStringUndefined: producto.imagen_url === 'undefined',
                    esStringNull: producto.imagen_url === 'null',
                    esVacio: producto.imagen_url === '',
                    valor: producto.imagen_url,
                    tipo: typeof producto.imagen_url,
                    longitud: producto.imagen_url ? producto.imagen_url.length : 0
                };
                console.log('📊 Estado imagen_url:', estadoImagen);
                
                // Detectar productos problemáticos
                if (!producto.imagen_url || 
                    producto.imagen_url === 'undefined' || 
                    producto.imagen_url === 'null' ||
                    producto.imagen_url === undefined ||
                    producto.imagen_url === null) {
                    console.log('⚠️ PRODUCTO CON IMAGEN PROBLEMÁTICA DETECTADO');
                    console.log('📋 Objeto completo:', producto);
                    productosProblematicos.push({
                        nombre: producto.nombre,
                        imagen_url: producto.imagen_url,
                        id: producto.id
                    });
                }
            });
            
            console.log(`\n📈 RESUMEN: ${productosProblematicos.length}/${productosData.length} productos con problemas de imagen`);
            
            if (productosProblematicos.length > 0) {
                console.log('❌ PRODUCTOS PROBLEMÁTICOS:');
                productosProblematicos.forEach(p => {
                    console.log(`  - "${p.nombre}": imagen_url = "${p.imagen_url}"`);
                });
            }
            
        } catch (error) {
            console.error('❌ Error al obtener productos:', error);
            setError(error.message);
        } finally {
            setLoading(false);
        }
    };

    // Función para limpiar entradas corruptas del cache
    const limpiarCacheCorrupto = () => {
        console.log('🧹 Limpiando cache corrupto...');
        let limpiadas = 0;
        
        for (const [id, url] of ApiService.productImageCache.entries()) {
            // Si es una URL uploaded/ que no sea base64, es corrupta
            if (typeof url === 'string' && url.startsWith('uploaded/') && !url.startsWith('data:')) {
                ApiService.productImageCache.delete(id);
                limpiadas++;
                console.log(`🗑️ Cache corrupto eliminado - ID: ${id}, URL: ${url}`);
            }
        }
        
        if (limpiadas > 0) {
            ApiService.saveImageCache();
            console.log(`✅ Cache limpiado: ${limpiadas} entradas corruptas eliminadas`);
        }
        
        return limpiadas;
    };

    useEffect(() => {
        console.log('🚀 Productos component montado, iniciando carga...');
        
        // Limpiar cache corrupto al montar el componente
        const limpiadas = limpiarCacheCorrupto();
        if (limpiadas > 0) {
            console.log(`🔄 Se limpiaron ${limpiadas} entradas corruptas, recargando productos...`);
        }
        
        fetchProductos();
    }, []);

    const handleEliminar = async (id) => {
        if (window.confirm('¿Estás seguro de que quieres eliminar este producto?')) {
            try {
                await apiService.deleteProducto(id);
                console.log('✅ Producto eliminado');
                fetchProductos(); // Recargar la lista
            } catch (error) {
                console.error('❌ Error al eliminar producto:', error);
                setError(error.message);
            }
        }
    };

    const handleEditar = (producto) => {
        setProductoEditando(producto);
        setMostrarModalEditar(true);
    };

    const handleCerrarModal = () => {
        setMostrarModalEditar(false);
        setProductoEditando(null);
    };

    const handleActualizarProducto = () => {
        handleCerrarModal();
        fetchProductos(); // Recargar la lista
    };

    const formatearPrecio = (precio) => {
        return new Intl.NumberFormat('es-CL', {
            style: 'currency',
            currency: 'CLP',
            minimumFractionDigits: 0
        }).format(precio);
    };

    if (loading) {
        return (
            <div className="container mx-auto px-4 py-8 text-center">
                <div className="flex items-center justify-center space-x-2">
                    <div className="w-4 h-4 bg-blue-500 rounded-full animate-pulse"></div>
                    <div className="w-4 h-4 bg-blue-500 rounded-full animate-pulse delay-75"></div>
                    <div className="w-4 h-4 bg-blue-500 rounded-full animate-pulse delay-150"></div>
                </div>
                <p className="mt-4 text-gray-600">Cargando productos...</p>
            </div>
        );
    }

    if (error) {
        return (
            <div className="container mx-auto px-4 py-8">
                <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
                    <strong className="font-bold">Error:</strong>
                    <span className="block sm:inline"> {error}</span>
                </div>
                <button
                    onClick={fetchProductos}
                    className="mt-4 bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
                >
                    Reintentar
                </button>
            </div>
        );
    }

    return (
        <div className="admin-products-container">
            <div className="products-header">
                <h2 className="dashboard-title">Gestión de Productos</h2>
                <Link
                    to="/crear-producto"
                    className={`action-btn ${productos.length === 0 ? 'create-first-btn' : ''}`}
                    title="Crear Producto"
                >
                    +
                </Link>
            </div>

            {productos.length === 0 ? (
                <div style={{ textAlign: 'center', padding: '40px 20px' }}>
                    <p style={{ color: '#888', fontSize: '1.1em', marginBottom: '20px' }}>
                        No hay productos disponibles.
                    </p>
                    <Link
                        to="/crear-producto"
                        className="submit-button"
                    >
                        Crear primer producto
                    </Link>
                </div>
            ) : (
                <div className="products-list">
                    {productos.map((producto) => (
                        <div key={producto.id} className="product-card-admin">
                            <div className="product-image-admin">
                                <img
                                    src={getImageUrl(producto)}
                                    alt={producto.nombre}
                                    onLoad={() => {
                                        console.log(`✅ Imagen cargada correctamente para "${producto.nombre}"`);
                                    }}
                                    onError={(e) => {
                                        console.error(`❌ Error cargando imagen para "${producto.nombre}":`, e.target.src);
                                        
                                        // Si es una imagen de archivo subido que no existe
                                        if (e.target.src.includes('/uploaded/')) {
                                            console.log('🔄 Archivo subido no encontrado, limpiando cache y usando imagen por defecto');
                                            
                                            // Limpiar cache corrupto para este producto
                                            ApiService.productImageCache.delete(producto.id);
                                            ApiService.saveImageCache();
                                            
                                            // Usar una imagen por defecto más apropiada según el tipo de producto
                                            const productLower = producto.nombre.toLowerCase();
                                            if (productLower.includes('polera') || productLower.includes('ropa')) {
                                                e.target.src = ImagenProducto1;
                                            } else if (productLower.includes('poleron')) {
                                                e.target.src = ImagenProducto2; 
                                            } else {
                                                e.target.src = ImagenProducto1; // Fallback general
                                            }
                                        } else {
                                            e.target.src = ImagenProducto1; // Fallback general
                                        }
                                    }}
                                />
                            </div>
                            
                            <div className="product-details-admin">
                                <h3 className="product-name-admin">
                                    {producto.nombre}
                                </h3>
                                <p className="product-stock">
                                    Stock: {producto.stock} unidades
                                </p>
                                <p className="product-description-admin">
                                    {producto.descripcion}
                                </p>
                            </div>
                            
                            <div className="product-price-admin">
                                {formatearPrecio(producto.precio)}
                            </div>
                            
                            <div className="product-actions">
                                <button
                                    onClick={() => handleEditar(producto)}
                                    className="edit-btn"
                                    title="Editar"
                                >
                                    Editar
                                </button>
                                <button
                                    onClick={() => handleEliminar(producto.id)}
                                    className="action-btn delete-btn"
                                    title="Eliminar"
                                >
                                    ✕
                                </button>
                            </div>
                        </div>
                    ))}
                </div>
            )}

            {/* Modal de Edición */}
            {mostrarModalEditar && (
                <EditarProducto
                    producto={productoEditando}
                    onClose={handleCerrarModal}
                    onUpdate={handleActualizarProducto}
                />
            )}
        </div>
    );
};

export default Productos;