import React from 'react';
import logoKebumy from '../../assets/logoKebumy.png';
import logoIG from '../../assets/Logo ig.png';
import logoCorreo from '../../assets/Logo correo.png';
import logoFacebook from '../../assets/Logo facebook.png';
import logoWSP from '../../assets/Logo_WSP.png';
import gatoSaludando from '../../assets/Gato_saludando.png';

export function Footer() {
    return (
        <footer style={{
            background: 'linear-gradient(to right, #eed5df, #ba81a0)',
            padding: '30px 50px',
            color: 'white'
        }}>
            <div style={{
                display: 'flex',
                justifyContent: 'space-around',
                alignItems: 'center',
                flexWrap: 'wrap',
                textAlign: 'center',
                maxWidth: '1200px',
                margin: '0 auto'
            }}>
                <div style={{ flex: 1, minWidth: '250px', margin: '10px' }}>
                    <img 
                        src={logoKebumy} 
                        alt="Kebumy Logo" 
                        style={{ width: '240px' }}
                    />
                    <div style={{ 
                        fontSize: '14px', 
                        marginTop: '15px', 
                        color: '#6a6a6a' 
                    }}>
                        Diseños únicos que reflejan lo especial que quieres transmitir.
                    </div>
                </div>
                
                <div style={{ flex: 1, minWidth: '250px', margin: '10px' }}>
                    <div style={{ marginBottom: '20px' }}>
                        <a 
                            href="https://instagram.com/kebumy" 
                            target="_blank" 
                            rel="noopener noreferrer"
                            style={{
                                color: '#964371',
                                textDecoration: 'none',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                margin: '10px 0'
                            }}
                        >
                            <img 
                                src={logoIG} 
                                alt="Instagram" 
                                style={{ width: '48px', height: '24px', marginRight: '10px' }}
                            />
                            @kebumy
                        </a>
                        <a 
                            href="https://facebook.com/kebumy" 
                            target="_blank" 
                            rel="noopener noreferrer"
                            style={{
                                color: '#964371',
                                textDecoration: 'none',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                margin: '10px 0'
                            }}
                        >
                            <img 
                                src={logoFacebook} 
                                alt="Facebook" 
                                style={{ width: '48px', height: '24px', marginRight: '10px' }}
                            />
                            kebumy
                        </a>
                    </div>
                    
                    <div>
                        <a 
                            href="mailto:kebumy.cliente@gmail.com"
                            style={{
                                color: '#964371',
                                textDecoration: 'none',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                margin: '10px 0',
                                fontSize: '14px'
                            }}
                        >
                            <img 
                                src={logoCorreo} 
                                alt="Email" 
                                style={{ width: '48px', height: '24px', marginRight: '10px' }}
                            />
                            kebumy.cliente@gmail.com
                        </a>
                        <a 
                            href="https://wa.me/56912345678" 
                            target="_blank" 
                            rel="noopener noreferrer"
                            style={{
                                color: '#964371',
                                textDecoration: 'none',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                margin: '10px 0',
                                fontSize: '14px'
                            }}
                        >
                            <img 
                                src={logoWSP} 
                                alt="WhatsApp" 
                                style={{ width: '48px', height: '24px', marginRight: '10px' }}
                            />
                            +56 9 1234 5678
                        </a>
                    </div>
                </div>
                
                <div style={{ flex: 1, minWidth: '250px', margin: '10px' }}>
                    <img 
                        src={gatoSaludando} 
                        alt="Gato Kebumy" 
                        style={{ width: '250px' }}
                    />
                </div>
            </div>
        </footer>
    );
}

export default Footer;