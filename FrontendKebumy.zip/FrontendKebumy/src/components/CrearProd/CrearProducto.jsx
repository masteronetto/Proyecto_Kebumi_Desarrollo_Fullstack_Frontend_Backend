import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Navbar } from '../Navbar/Navbar';
import apiService from '../../services/apiService';
import { ApiService } from '../../services/apiService';

export default function CrearProducto() {
    const navigate = useNavigate();
    const [producto, setProducto] = useState({
        nombre: '',
        descripcion: '',
        precio: '',
        categoria_nombre: '',
        stock: '',
        imagen_url: '',
        estado: 'activo'
    });
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    
    // Estados para manejo de imágenes
    const [tipoImagen, setTipoImagen] = useState('url'); // 'url' o 'archivo'
    const [archivoImagen, setArchivoImagen] = useState(null);
    const [previewImagen, setPreviewImagen] = useState(null);
    const [validandoUrl, setValidandoUrl] = useState(false);
    const [urlValida, setUrlValida] = useState(null);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setProducto(prev => ({
            ...prev,
            [name]: value
        }));
        
        // Si es el campo imagen_url, validar en tiempo real
        if (name === 'imagen_url' && tipoImagen === 'url') {
            validarUrlImagen(value);
        }
    };

    const validarUrlImagen = async (url) => {
        if (!url.trim()) {
            setUrlValida(null);
            setPreviewImagen(null);
            return;
        }
        
        setValidandoUrl(true);
        
        try {
            // Validar que sea una URL válida
            new URL(url);
            
            // Verificar que sea una imagen válida
            const img = new Image();
            img.onload = () => {
                setUrlValida(true);
                setPreviewImagen(url);
                setValidandoUrl(false);
                console.log('✅ URL de imagen válida:', url);
            };
            img.onerror = () => {
                setUrlValida(false);
                setPreviewImagen(null);
                setValidandoUrl(false);
                console.log('❌ URL de imagen inválida:', url);
            };
            img.src = url;
        } catch {
            setUrlValida(false);
            setPreviewImagen(null);
            setValidandoUrl(false);
        }
    };

    const handleTipoImagenChange = (tipo) => {
        setTipoImagen(tipo);
        setArchivoImagen(null);
        setPreviewImagen(null);
        setUrlValida(null);
        setProducto(prev => ({ ...prev, imagen_url: '' }));
    };

    const handleFileChange = (e) => {
        const file = e.target.files[0];
        
        if (!file) {
            setArchivoImagen(null);
            setPreviewImagen(null);
            return;
        }

        // Validar que sea una imagen
        if (!file.type.startsWith('image/')) {
            setError('Por favor selecciona un archivo de imagen válido.');
            return;
        }

        // Validar tamaño (máximo 5MB)
        if (file.size > 5 * 1024 * 1024) {
            setError('La imagen debe ser menor a 5MB.');
            return;
        }

        setError(null);
        setArchivoImagen(file);

        // Crear preview
        const reader = new FileReader();
        reader.onload = (e) => {
            setPreviewImagen(e.target.result);
        };
        reader.readAsDataURL(file);

        console.log('📁 Archivo seleccionado:', {
            nombre: file.name,
            tipo: file.type,
            tamaño: `${(file.size / 1024 / 1024).toFixed(2)}MB`
        });
    };

    const procesarImagen = async () => {
        if (tipoImagen === 'url') {
            // Para URLs externas, simplemente usar la URL
            console.log('🔗 Usando URL externa:', producto.imagen_url);
            return producto.imagen_url;
        } else if (tipoImagen === 'archivo' && archivoImagen) {
            console.log('📤 Procesando archivo local a base64:', archivoImagen.name);
            console.log('📊 Tamaño original:', Math.round(archivoImagen.size / 1024), 'KB');
            
            // NUEVA ESTRATEGIA: Convertir siempre a base64 para guardar directamente en BD
            return new Promise((resolve, reject) => {
                const reader = new FileReader();
                
                reader.onload = (e) => {
                    const base64Image = e.target.result;
                    console.log('✅ Imagen convertida a base64 exitosamente');
                    console.log('📊 Tamaño base64:', Math.round(base64Image.length / 1024), 'KB');
                    
                    // Retornar directamente la imagen base64 para guardar en BD
                    resolve(base64Image);
                };
                
                reader.onerror = (error) => {
                    console.error('❌ Error convirtiendo imagen a base64:', error);
                    reject(new Error('No se pudo procesar la imagen'));
                };
                
                // Convertir archivo a base64
                reader.readAsDataURL(archivoImagen);
            });
        }
        
        return '';
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        setError(null);

        // Validación básica
        if (
            !producto.nombre.trim() ||
            !producto.descripcion.trim() ||
            !producto.precio ||
            !producto.categoria_nombre.trim() ||
            !producto.stock
        ) {
            setError('Todos los campos son obligatorios.');
            setLoading(false);
            return;
        }

        // Validación de precio y stock
        const precioNum = Number(producto.precio);
        const stockNum = Number(producto.stock);
        if (isNaN(precioNum) || precioNum < 0) {
            setError('El precio debe ser un número positivo.');
            setLoading(false);
            return;
        }
        if (isNaN(stockNum) || stockNum < 0) {
            setError('El stock debe ser un número positivo.');
            setLoading(false);
            return;
        }

        // Validación de imagen según tipo
        if (tipoImagen === 'url' && producto.imagen_url && !urlValida) {
            setError('La URL de la imagen no es válida o no se puede cargar.');
            setLoading(false);
            return;
        }

        if (tipoImagen === 'archivo' && !archivoImagen) {
            setError('Por favor selecciona un archivo de imagen.');
            setLoading(false);
            return;
        }

        try {
            console.log('🔄 Procesando imagen...');
            const imagenUrl = await procesarImagen();
            
            const dataToSend = {
                ...producto,
                precio: precioNum,
                stock: stockNum,
                imagen_url: imagenUrl
            };

            console.log('🔄 Datos a enviar al backend:', {
                ...dataToSend,
                imagen_url_detalle: {
                    valor: imagenUrl,
                    tipo: typeof imagenUrl,
                    longitud: imagenUrl?.length,
                    esBase64: imagenUrl?.startsWith('data:image/')
                }
            });
            
            console.log('🔄 Creando producto:', dataToSend);
            const response = await apiService.createProducto(dataToSend);
            
            console.log('✅ Respuesta del backend:', response);
            console.log('✅ Producto creado exitosamente');
            
            // Si es una URL externa, guardarla en cache para persistencia
            if (response.id && imagenUrl && (imagenUrl.startsWith('http://') || imagenUrl.startsWith('https://'))) {
                console.log('💾 Guardando URL externa en cache...');
                ApiService.setProductImage(response.id, imagenUrl, {
                    tipo: 'url_externa',
                    origen: 'crear_producto',
                    timestamp: Date.now()
                });
                console.log(`✅ URL guardada en cache para producto ID: ${response.id}`);
            }
            
            // Limpiar formulario
            setProducto({
                nombre: '',
                descripcion: '',
                precio: '',
                categoria_nombre: '',
                stock: '',
                imagen_url: '',
                estado: 'activo'
            });
            setArchivoImagen(null);
            setPreviewImagen(null);
            setUrlValida(null);
            
            navigate('/inventario');
        } catch (err) {
            console.error('❌ Error al crear producto:', err);
            setError(err.message || 'Error al crear producto');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="container">
            <Navbar />
            <div className="admin-products-container" style={{ marginTop: '20px' }}>
                <h3 style={{ color: '#555', marginBottom: '20px' }}>✨ Crear Nuevo Producto</h3>
                
                {error && (
                    <div style={{
                        backgroundColor: '#f8d7da',
                        color: '#721c24',
                        padding: '15px',
                        borderRadius: '8px',
                        marginBottom: '20px',
                        border: '1px solid #f5c6cb'
                    }}>
                        ❌ {error}
                    </div>
                )}

                <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
                    {/* Información básica */}
                    <div className="product-card-admin">
                        <h4 style={{ color: '#b0417a', marginBottom: '15px' }}>📝 Información Básica</h4>
                        
                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px', marginBottom: '15px' }}>
                            <div>
                                <label style={{ display: 'block', marginBottom: '5px', color: '#555', fontWeight: 'bold' }}>
                                    Nombre del Producto *
                                </label>
                                <input
                                    type="text"
                                    name="nombre"
                                    value={producto.nombre || ''}
                                    onChange={handleChange}
                                    required
                                    style={{
                                        width: '100%',
                                        padding: '10px',
                                        border: '1px solid #ddd',
                                        borderRadius: '8px',
                                        fontSize: '14px'
                                    }}
                                    placeholder="Ej: Poleras con Diseños Exclusivos"
                                />
                            </div>
                            
                            <div>
                                <label style={{ display: 'block', marginBottom: '5px', color: '#555', fontWeight: 'bold' }}>
                                    Categoría *
                                </label>
                                <select
                                    name="categoria_nombre"
                                    value={producto.categoria_nombre || ''}
                                    onChange={handleChange}
                                    required
                                    style={{
                                        width: '100%',
                                        padding: '10px',
                                        border: '1px solid #ddd',
                                        borderRadius: '8px',
                                        fontSize: '14px'
                                    }}
                                >
                                    <option value="">Seleccionar categoría</option>
                                    <option value="Para ti">Para ti</option>
                                    <option value="Para marcas">Para marcas</option>
                                </select>
                            </div>
                        </div>

                        <div style={{ marginBottom: '15px' }}>
                            <label style={{ display: 'block', marginBottom: '5px', color: '#555', fontWeight: 'bold' }}>
                                Descripción *
                            </label>
                            <textarea
                                name="descripcion"
                                value={producto.descripcion || ''}
                                onChange={handleChange}
                                required
                                rows="3"
                                style={{
                                    width: '100%',
                                    padding: '10px',
                                    border: '1px solid #ddd',
                                    borderRadius: '8px',
                                    fontSize: '14px',
                                    resize: 'vertical'
                                }}
                                placeholder="Describe las características y beneficios del producto..."
                            />
                        </div>

                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px' }}>
                            <div>
                                <label style={{ display: 'block', marginBottom: '5px', color: '#555', fontWeight: 'bold' }}>
                                    Precio (CLP) *
                                </label>
                                <input
                                    type="number"
                                    name="precio"
                                    value={producto.precio || ''}
                                    onChange={handleChange}
                                    min="0"
                                    step="100"
                                    required
                                    style={{
                                        width: '100%',
                                        padding: '10px',
                                        border: '1px solid #ddd',
                                        borderRadius: '8px',
                                        fontSize: '14px'
                                    }}
                                    placeholder="15990"
                                />
                            </div>
                            
                            <div>
                                <label style={{ display: 'block', marginBottom: '5px', color: '#555', fontWeight: 'bold' }}>
                                    Stock Inicial *
                                </label>
                                <input
                                    type="number"
                                    name="stock"
                                    value={producto.stock || ''}
                                    onChange={handleChange}
                                    min="0"
                                    required
                                    style={{
                                        width: '100%',
                                        padding: '10px',
                                        border: '1px solid #ddd',
                                        borderRadius: '8px',
                                        fontSize: '14px'
                                    }}
                                    placeholder="50"
                                />
                            </div>
                        </div>
                    </div>

                    {/* Sección de imagen */}
                    <div className="product-card-admin">
                        <h4 style={{ color: '#b0417a', marginBottom: '15px' }}>🖼️ Imagen del Producto</h4>
                        
                        {/* Selector de tipo de imagen */}
                        <div style={{ marginBottom: '20px' }}>
                            <label style={{ display: 'block', marginBottom: '10px', color: '#555', fontWeight: 'bold' }}>
                                Tipo de imagen:
                            </label>
                            <div style={{ display: 'flex', gap: '15px' }}>
                                <label style={{ display: 'flex', alignItems: 'center', cursor: 'pointer' }}>
                                    <input
                                        type="radio"
                                        value="url"
                                        checked={tipoImagen === 'url'}
                                        onChange={() => handleTipoImagenChange('url')}
                                        style={{ marginRight: '8px' }}
                                    />
                                    🌐 URL externa
                                </label>
                                <label style={{ display: 'flex', alignItems: 'center', cursor: 'pointer' }}>
                                    <input
                                        type="radio"
                                        value="archivo"
                                        checked={tipoImagen === 'archivo'}
                                        onChange={() => handleTipoImagenChange('archivo')}
                                        style={{ marginRight: '8px' }}
                                    />
                                    📁 Subir archivo
                                </label>
                            </div>
                        </div>

                        {/* Input según tipo seleccionado */}
                        {tipoImagen === 'url' ? (
                            <div style={{ marginBottom: '15px' }}>
                                <label style={{ display: 'block', marginBottom: '5px', color: '#555', fontWeight: 'bold' }}>
                                    URL de la imagen
                                </label>
                                <input
                                    type="url"
                                    name="imagen_url"
                                    value={producto.imagen_url || ''}
                                    onChange={handleChange}
                                    style={{
                                        width: '100%',
                                        padding: '10px',
                                        border: `1px solid ${urlValida === false ? '#dc3545' : (urlValida === true ? '#28a745' : '#ddd')}`,
                                        borderRadius: '8px',
                                        fontSize: '14px'
                                    }}
                                    placeholder="https://ejemplo.com/imagen.jpg"
                                />
                                {validandoUrl && (
                                    <div style={{ marginTop: '5px', color: '#6c757d', fontSize: '12px' }}>
                                        🔄 Validando URL...
                                    </div>
                                )}
                                {urlValida === false && (
                                    <div style={{ marginTop: '5px', color: '#dc3545', fontSize: '12px' }}>
                                        ❌ URL inválida o imagen no accesible
                                    </div>
                                )}
                                {urlValida === true && (
                                    <div style={{ marginTop: '5px', color: '#28a745', fontSize: '12px' }}>
                                        ✅ URL válida
                                    </div>
                                )}
                            </div>
                        ) : (
                            <div style={{ marginBottom: '15px' }}>
                                <label style={{ display: 'block', marginBottom: '5px', color: '#555', fontWeight: 'bold' }}>
                                    Seleccionar archivo de imagen
                                </label>
                                <input
                                    type="file"
                                    accept="image/*"
                                    onChange={handleFileChange}
                                    style={{
                                        width: '100%',
                                        padding: '10px',
                                        border: '1px solid #ddd',
                                        borderRadius: '8px',
                                        fontSize: '14px'
                                    }}
                                />
                                <div style={{ marginTop: '5px', color: '#6c757d', fontSize: '12px' }}>
                                    Formatos soportados: JPG, PNG, GIF, WebP (máx. 5MB)
                                </div>
                                {archivoImagen && (
                                    <div style={{ marginTop: '5px', color: '#28a745', fontSize: '12px' }}>
                                        ✅ Archivo seleccionado: {archivoImagen.name} ({(archivoImagen.size / 1024 / 1024).toFixed(2)}MB)
                                    </div>
                                )}
                            </div>
                        )}

                        {/* Preview de imagen */}
                        {previewImagen && (
                            <div style={{ marginTop: '15px' }}>
                                <label style={{ display: 'block', marginBottom: '10px', color: '#555', fontWeight: 'bold' }}>
                                    Vista previa:
                                </label>
                                <div style={{ 
                                    border: '2px solid #ddd', 
                                    borderRadius: '8px', 
                                    padding: '10px',
                                    display: 'inline-block'
                                }}>
                                    <img
                                        src={previewImagen}
                                        alt="Preview"
                                        style={{
                                            maxWidth: '200px',
                                            maxHeight: '200px',
                                            objectFit: 'contain',
                                            borderRadius: '4px'
                                        }}
                                    />
                                </div>
                            </div>
                        )}
                    </div>

                    {/* Botones de acción */}
                    <div style={{ display: 'flex', gap: '15px', justifyContent: 'flex-end' }}>
                        <button
                            type="button"
                            onClick={() => navigate('/inventario')}
                            style={{
                                backgroundColor: '#6c757d',
                                color: 'white',
                                padding: '12px 24px',
                                border: 'none',
                                borderRadius: '8px',
                                fontSize: '14px',
                                cursor: 'pointer'
                            }}
                        >
                            ❌ Cancelar
                        </button>
                        <button
                            type="submit"
                            disabled={loading}
                            style={{
                                backgroundColor: loading ? '#ccc' : '#b0417a',
                                color: 'white',
                                padding: '12px 24px',
                                border: 'none',
                                borderRadius: '8px',
                                fontSize: '14px',
                                cursor: loading ? 'not-allowed' : 'pointer'
                            }}
                        >
                            {loading ? '⏳ Guardando...' : '✅ Guardar Producto'}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
}