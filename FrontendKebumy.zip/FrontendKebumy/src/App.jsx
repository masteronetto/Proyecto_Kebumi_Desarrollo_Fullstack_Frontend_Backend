import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Home from './pages/Home/Home'; 
import Contacto from './pages/Contacto/Contacto'; 
import Inventario from './pages/Inventario/Inventario'; 
import CrearProducto from './components/CrearProd/CrearProducto'; 
import Login from './pages/Login/Login'; 
import AdminUsuarios from './pages/Usuarios/Adminusuarios';
import CrearUsuario from './components/Usuarios/CrearUsuario';
import ProtectedRoute from './components/ProtectedRoute';
import BackendToggle from './components/BackendToggle/BackendToggle';
import './App.css'; 
import './styles/GlobalStyles.css';

function App() {
  return (
    <Router>
      {/* Componente para alternar entre backend real y mock (solo en desarrollo) */}
      {import.meta.env.DEV && <BackendToggle />}
      
      <Routes>
        {/* Rutas Públicas */}
        <Route path="/" element={<Home />} /> 
        <Route path="/contacto" element={<Contacto />} />
        <Route path="/login" element={<Login />} /> 
        
        {/* Rutas Protegidas - Solo para administradores autenticados */}
        <Route 
          path="/inventario" 
          element={
            <ProtectedRoute>
              <Inventario />
            </ProtectedRoute>
          } 
        />
        <Route 
          path="/crear-producto" 
          element={
            <ProtectedRoute>
              <CrearProducto />
            </ProtectedRoute>
          } 
        />
        <Route 
          path="/admin-usuarios" 
          element={
            <ProtectedRoute>
              <AdminUsuarios />
            </ProtectedRoute>
          } 
        />
        <Route 
          path="/crear-usuario" 
          element={
            <ProtectedRoute>
              <CrearUsuario />
            </ProtectedRoute>
          } 
        />
        
        {/* Ruta por defecto - redirige a Home */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Router>
  );
}

export default App;