import { useState, useEffect } from 'react';

const useAuth = () => {
  const [user, setUser] = useState(() => {
    const storedUser = localStorage.getItem('user');
    return storedUser ? JSON.parse(storedUser) : null;
  });

  // Mejorar la validación de autenticación - más flexible
  const isAuthenticated = !!user && (user.role === 'ADMIN' || user.rol === 'super-admin' || user.email);

  useEffect(() => {
    if (user) {
      localStorage.setItem('user', JSON.stringify(user));
    } else {
      localStorage.removeItem('user');
    }
  }, [user]);

  const login = (userData) => {
    console.log('🔍 useAuth - Recibiendo datos para login:', userData);
    
    // Verificar estructura de datos más flexible
    const email = userData?.email;
    const role = userData?.role || userData?.rol; // Flexible para rol/role
    
    console.log('🔍 useAuth - Email:', email, 'Role:', role);
    
    // Validar que los datos del usuario sean válidos
    if (userData && email) {
      // Normalizar el objeto de usuario
      const normalizedUser = {
        ...userData,
        role: role || 'ADMIN', // Establecer ADMIN por defecto
        email: email
      };
      
      console.log('✅ useAuth - Usuario normalizado:', normalizedUser);
      setUser(normalizedUser);
      return true; 
    }
    
    console.log('❌ useAuth - Datos inválidos para login');
    return false;
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('user');
  };

  // Función para verificar si el usuario tiene permisos específicos
  const hasPermission = (requiredRole) => {
    if (!user) return false;
    
    // Para este proyecto, todos los administradores tienen acceso completo
    return user.role === 'ADMIN';
  };

  return {
    user,
    isAuthenticated,
    login,
    logout,
    hasPermission,
  };
};

export default useAuth;