# 🚨 Solución al Error "Failed to fetch"

## 🔍 **Diagnóstico del Problema**

### **Error Identificado:**
- ✅ Health check funciona (puerto 3000)
- ❌ API endpoints fallan (puerto 8081)
- 🚨 Causa: **CORS no configurado para puerto 5174**

## ⚡ **Solución Inmediata**

### **Opción 1: Configurar CORS en tu Backend (Recomendado)**

En tu backend Spring Boot, actualizar la configuración CORS:

```java
@CrossOrigin(origins = {
    "http://localhost:5173", 
    "http://localhost:5174"  // ← Agregar este puerto
})
```

O en tu clase de configuración CORS:

```java
@Configuration
public class CorsConfig {
    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration configuration = new CorsConfiguration();
        configuration.setAllowedOrigins(Arrays.asList(
            "http://localhost:5173",
            "http://localhost:5174"  // ← Agregar este puerto
        ));
        configuration.setAllowedMethods(Arrays.asList("GET", "POST", "PUT", "DELETE", "OPTIONS"));
        configuration.setAllowedHeaders(Arrays.asList("*"));
        configuration.setAllowCredentials(true);
        
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", configuration);
        return source;
    }
}
```

### **Opción 2: Cambiar Puerto del Frontend**

```bash
# Cerrar el servidor actual (Ctrl+C en terminal)
# Liberar puerto 5173 y ejecutar:
npm run dev
```

## 🧪 **Pasos para Verificar la Solución**

### **1. Después de actualizar CORS:**
1. Reiniciar tu backend Spring Boot
2. En el frontend, hacer clic en "Test" 
3. Revisar consola (F12) para logs detallados

### **2. Test Manual:**
Abrir consola del navegador (F12) y ejecutar:

```javascript
// Test directo del endpoint usuarios
fetch('http://localhost:8081/api/usuarios', {
    method: 'GET',
    headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
    },
    mode: 'cors'
})
.then(response => {
    console.log('Status:', response.status);
    console.log('Headers:', [...response.headers.entries()]);
    return response.json();
})
.then(data => console.log('Data:', data))
.catch(error => console.error('Error:', error));
```

## 📋 **Checklist de Verificación**

- [ ] ✅ Health check funciona (http://localhost:3000/api/health)
- [ ] 🔄 Backend permite CORS desde puerto 5174
- [ ] 🔄 Endpoint `/api/usuarios` existe en tu backend
- [ ] 🔄 Endpoint `/api/productos` existe en tu backend
- [ ] 🔄 Backend reiniciado después de cambios CORS

## 🎯 **Resultado Esperado**

Después de la corrección, deberías ver:
- ✅ Toggle muestra "Backend conectado correctamente"
- ✅ Lista de usuarios se carga desde tu base de datos MySQL
- ✅ Consola muestra: "Usuarios obtenidos correctamente"

## 🚨 **Si Persiste el Error**

### **Verificar endpoints en tu backend:**
1. ¿Existe el controlador para `/api/usuarios`?
2. ¿Está mapeado correctamente?
3. ¿La base de datos tiene datos en la tabla usuarios?

### **Test adicional:**
```bash
# Probar directamente con curl
curl -X GET "http://localhost:8081/api/usuarios" \
     -H "Accept: application/json" \
     -H "Origin: http://localhost:5174"
```

---

**💡 El 99% de las veces este error se soluciona agregando el puerto 5174 a la configuración CORS del backend.**