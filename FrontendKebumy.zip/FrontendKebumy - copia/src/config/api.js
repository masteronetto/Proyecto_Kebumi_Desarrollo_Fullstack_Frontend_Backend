// src/config/api.js
// Configuración para el manejo de la API y conexión con backend

export const API_CONFIG = {
    // Cambiar a true cuando el backend esté disponible
    USE_REAL_BACKEND: false,
    
    // URL base del backend Spring Boot (CORREGIDO: puerto 3000)
    BASE_URL: 'http://localhost:3000/api',
    
    // URL para health check (mismo puerto)
    HEALTH_CHECK_URL: 'http://localhost:3000/api/health',
    
    // Endpoints de la API según tu backend (CORREGIDOS)
    ENDPOINTS: {
        // Autenticación (CORREGIDO: /usuarios/login)
        LOGIN: '/usuarios/login',
        LOGOUT: '/usuarios/logout',
        REGISTRO: '/usuarios/registro',
        
        // Productos
        PRODUCTOS: '/productos',
        PRODUCTO_BY_ID: (id) => `/productos/${id}`,
        
        // Usuarios (CORREGIDO: endpoints específicos)
        USUARIOS: '/usuarios',
        USUARIO_BY_ID: (id) => `/usuarios/${id}`,
        CREAR_USUARIO_ADMIN: '/usuarios/admin', // Endpoint específico para crear usuarios
        
        // Health check y test endpoints
        HEALTH: '/health',
        TEST_CORS: '/test-cors',
        
        // Categorías (si las tienes)
        CATEGORIAS: '/categorias',
    },
    
    // Headers por defecto
    DEFAULT_HEADERS: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
    },
    
    // Configuración para manejo de errores
    ERROR_MESSAGES: {
        NETWORK_ERROR: 'Error de conexión. Verifique que el backend esté ejecutándose.',
        UNAUTHORIZED: 'No autorizado. Inicie sesión nuevamente.',
        FORBIDDEN: 'No tiene permisos para realizar esta acción.',
        NOT_FOUND: 'Recurso no encontrado.',
        SERVER_ERROR: 'Error interno del servidor.',
        VALIDATION_ERROR: 'Error de validación en los datos enviados.',
    }
};

// Datos de ejemplo para desarrollo sin backend
export const MOCK_DATA = {
    // Usuarios de ejemplo
    USUARIOS: [
        {
            id: 1,
            nombre: "Admin Kebumy",
            email: "admin@kebumy.com",
            password: "admin_pass",
            rol: "super-admin",
            estado: "activo",
            fecha_creacion: "2024-01-15",
            ultimoAcceso: "2024-10-08"
        },
        {
            id: 2,
            nombre: "Ana Torres",
            email: "ana.t@cliente.com",
            password: "contrasena", 
            rol: "cliente",
            estado: "activo",
            fecha_creacion: "2025-01-01",
            ultimoAcceso: "2024-10-07"
        },
        {
            id: 3,
            nombre: "Carlos López",
            email: "carlos.l@cliente.com",
            password: "contrasena",
            rol: "cliente",
            estado: "activo",
            fecha_creacion: "2025-01-15",
            ultimoAcceso: "2024-10-05"
        },
        {
            id: 4,
            nombre: "Usuario Inactivo",
            email: "inactivo@cliente.com",
            password: "contrasena",
            rol: "cliente",
            estado: "inactivo",
            fecha_creacion: "2025-02-01",
            ultimoAcceso: "2024-09-30"
        }
    ],
    
    // Productos completos (coinciden exactamente con base de datos MySQL)
    PRODUCTOS: [
        // Categoría: Para Ti
        {
            id: 1,
            nombre: "Poleras con Diseños",
            descripcion: "Poleras personalizadas con diseños únicos.",
            precio: 15990,
            stock: 8,
            categoria_nombre: "Para ti",
            imagen_url: "img/Polera.png",
            estado: "activo",
            fecha_creacion: "2024-01-20"
        },
        {
            id: 2,
            nombre: "Polerones Exclusivos",
            descripcion: "Polerones con diseños exclusivos y felpa.",
            precio: 25000,
            stock: 3, // 🚨 STOCK BAJO (<5)
            categoria_nombre: "Para ti",
            imagen_url: "img/Poleron.png",
            estado: "activo",
            fecha_creacion: "2024-02-01"
        },
        {
            id: 3,
            nombre: "Libretas A5 Classic",
            descripcion: "Libretas de formato A5 de alta calidad.",
            precio: 5200,
            stock: 12,
            categoria_nombre: "Para ti",
            imagen_url: "img/Agenda.png",
            estado: "activo",
            fecha_creacion: "2024-02-15"
        },
        {
            id: 4,
            nombre: "Stickers Vinilo Pack",
            descripcion: "Pack de stickers de vinilo personalizados.",
            precio: 3800,
            stock: 50,
            categoria_nombre: "Para ti",
            imagen_url: "img/sticker.png",
            estado: "activo",
            fecha_creacion: "2024-03-01"
        },
        {
            id: 5,
            nombre: "Fotografías Polaroid",
            descripcion: "Impresiones de fotografías estilo Polaroid.",
            precio: 2500,
            stock: 10,
            categoria_nombre: "Para ti",
            imagen_url: "img/Polaroid.png",
            estado: "activo",
            fecha_creacion: "2024-03-10"
        },
        // Categoría: Para Marcas
        {
            id: 6,
            nombre: "Calendarios Imantados",
            descripcion: "Calendarios personalizados para empresas.",
            precio: 5000,
            stock: 30,
            categoria_nombre: "Para marcas",
            imagen_url: "img/miniCalendario.png",
            estado: "activo",
            fecha_creacion: "2024-03-15"
        },
        {
            id: 7,
            nombre: "Poleras de Empresa Logo",
            descripcion: "Poleras para tu equipo de trabajo o eventos.",
            precio: 12000,
            stock: 40,
            categoria_nombre: "Para marcas",
            imagen_url: "img/PolerasMarca.png",
            estado: "activo",
            fecha_creacion: "2024-03-20"
        },
        {
            id: 8,
            nombre: "Tarjetas Presentación",
            descripcion: "Tarjetas de presentación de alta calidad.",
            precio: 6000,
            stock: 60,
            categoria_nombre: "Para marcas",
            imagen_url: "img/tarjetaPresentacion.png",
            estado: "activo",
            fecha_creacion: "2024-03-25"
        },
        {
            id: 9,
            nombre: "Etiquetas para Ropa Cuero",
            descripcion: "Etiquetas de tela o cartón para vestuario.",
            precio: 300,
            stock: 200,
            categoria_nombre: "Para marcas",
            imagen_url: "img/etiquetaCuero.png",
            estado: "activo",
            fecha_creacion: "2024-03-28"
        },
        {
            id: 10,
            nombre: "Stickers de Marca Logo",
            descripcion: "Stickers de vinilo para empaques y productos.",
            precio: 3500,
            stock: 150,
            categoria_nombre: "Para marcas",
            imagen_url: "img/stickerMarca.png",
            estado: "activo",
            fecha_creacion: "2024-04-01"
        },
        {
            id: 11,
            nombre: "Mochilas Estampadas",
            descripcion: "Mochilas funcionales con tu logo estampado.",
            precio: 22000,
            stock: 18,
            categoria_nombre: "Para marcas",
            imagen_url: "img/Mochila.png",
            estado: "activo",
            fecha_creacion: "2024-04-15"
        }
    ],
    
    // Categorías de ejemplo
    CATEGORIAS: [
        { id: 1, nombre: "Ropa", descripcion: "Prendas de vestir personalizadas" },
        { id: 2, nombre: "Adhesivos", descripcion: "Stickers y calcomanías" },
        { id: 3, nombre: "Hogar", descripcion: "Artículos para el hogar" },
        { id: 4, nombre: "Decoración", descripcion: "Elementos decorativos" }
    ]
};

// Función helper para simular delay de red en desarrollo
export const simulateNetworkDelay = (ms = 500) => {
    return new Promise(resolve => setTimeout(resolve, ms));
};