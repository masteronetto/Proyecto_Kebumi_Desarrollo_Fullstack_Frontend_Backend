// src/services/apiService.js
// Servicio para manejar todas las llamadas a la API

import { API_CONFIG, MOCK_DATA, simulateNetworkDelay } from '../config/api.js';

class ApiService {
    constructor() {
        this.baseURL = API_CONFIG.BASE_URL;
        
        // Inicializar desde localStorage si existe
        const savedMode = localStorage.getItem('kebumy_backend_mode');
        if (savedMode !== null) {
            this.useRealBackend = JSON.parse(savedMode);
            API_CONFIG.USE_REAL_BACKEND = this.useRealBackend;
        } else {
            this.useRealBackend = API_CONFIG.USE_REAL_BACKEND;
        }
        
        console.log(`🔧 ApiService inicializado: ${this.useRealBackend ? 'Backend Real' : 'Modo Mock'}`);
    }

    // Método helper para hacer peticiones HTTP
    async makeRequest(url, options = {}) {
        const config = {
            mode: 'cors',
            credentials: 'omit',
            headers: {
                ...API_CONFIG.DEFAULT_HEADERS,
                ...options.headers,
            },
            ...options,
        };

        // Agregar token de autenticación si existe
        const token = localStorage.getItem('authToken');
        if (token) {
            config.headers.Authorization = `Bearer ${token}`;
        }

        console.log(`🌐 Haciendo petición a: ${this.baseURL}${url}`);
        console.log(`🔧 Configuración:`, { method: config.method || 'GET', headers: config.headers });

        try {
            const response = await fetch(`${this.baseURL}${url}`, config);
            
            console.log(`📥 Respuesta recibida:`, { status: response.status, statusText: response.statusText });
            
            // Manejar diferentes códigos de estado
            if (!response.ok) {
                await this.handleErrorResponse(response);
            }

            // Si la respuesta es exitosa, parsear JSON
            const contentType = response.headers.get('content-type');
            if (contentType && contentType.includes('application/json')) {
                return await response.json();
            }
            
            return response;
        } catch (error) {
            console.error('❌ Error en la petición:', error);
            console.error('🔍 Detalles del error:', {
                name: error.name,
                message: error.message,
                url: `${this.baseURL}${url}`
            });
            
            if (error.name === 'TypeError' && error.message.includes('fetch')) {
                throw new Error(`Error de conexión: No se puede conectar al backend en ${this.baseURL}. Verifica que el backend esté corriendo en puerto 3000.`);
            }
            
            throw error;
        }
    }

    // Manejar respuestas de error
    async handleErrorResponse(response) {
        const errorData = await response.json().catch(() => ({}));
        
        switch (response.status) {
            case 401:
                localStorage.removeItem('authToken');
                localStorage.removeItem('user');
                throw new Error(API_CONFIG.ERROR_MESSAGES.UNAUTHORIZED);
            case 403:
                throw new Error(API_CONFIG.ERROR_MESSAGES.FORBIDDEN);
            case 404:
                throw new Error(API_CONFIG.ERROR_MESSAGES.NOT_FOUND);
            case 422:
                throw new Error(errorData.message || API_CONFIG.ERROR_MESSAGES.VALIDATION_ERROR);
            case 500:
                throw new Error(API_CONFIG.ERROR_MESSAGES.SERVER_ERROR);
            default:
                throw new Error(errorData.message || `Error ${response.status}: ${response.statusText}`);
        }
    }

    // === AUTENTICACIÓN ===
    
    async login(credentials) {
        console.log('🔐 Iniciando login con:', { email: credentials.email, useRealBackend: this.useRealBackend });
        
        if (!this.useRealBackend) {
            // Modo desarrollo con datos mock
            await simulateNetworkDelay();
            
            if (credentials.email === 'admin@kebumy.com' && credentials.password === 'admin_pass') {
                const userData = {
                    id: 1,
                    email: credentials.email,
                    role: 'ADMIN',
                    name: 'Administrador Kebumy',
                    roleType: credentials.role || 'super-admin',
                    token: 'mock-jwt-token-12345'
                };
                
                // Simular almacenamiento de token
                localStorage.setItem('authToken', userData.token);
                console.log('✅ Login mock exitoso:', userData);
                return userData;
            } else {
                console.log('❌ Credenciales mock inválidas');
                throw new Error('Credenciales inválidas');
            }
        }

        // Modo producción con backend real
        console.log('🌐 Intentando login con backend real en:', `${this.baseURL}${API_CONFIG.ENDPOINTS.LOGIN}`);
        
        try {
            const loginData = {
                email: credentials.email,
                password: credentials.password
            };
            
            console.log('📤 Enviando datos de login:', { email: loginData.email });
            
            const response = await fetch(`${this.baseURL}${API_CONFIG.ENDPOINTS.LOGIN}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                },
                mode: 'cors',
                body: JSON.stringify(loginData),
            });

            console.log('📥 Respuesta del login - Status:', response.status);
            console.log('📥 Respuesta del login - Headers:', [...response.headers.entries()]);

            if (!response.ok) {
                const errorText = await response.text().catch(() => 'No response body');
                console.error('❌ Error en login - Status:', response.status, 'Body:', errorText);
                throw new Error(`Error ${response.status}: ${errorText || response.statusText}`);
            }

            const data = await response.json();
            console.log('✅ Login response data:', data);

            // Manejar diferentes estructuras de respuesta del backend
            let userData = null;
            
            if (data.success && data.data) {
                // Estructura: { success: true, data: { ... } }
                userData = data.data;
            } else if (data.token || data.email) {
                // Estructura directa: { token: "...", email: "...", ... }
                userData = data;
            } else if (data.usuario || data.user) {
                // Estructura: { usuario: { ... } } o { user: { ... } }
                userData = data.usuario || data.user;
            }
            
            if (userData) {
                // Normalizar el objeto de usuario
                const normalizedUser = {
                    id: userData.id,
                    email: userData.email,
                    nombre: userData.nombre || userData.name,
                    role: userData.role || userData.rol || 'ADMIN',
                    token: userData.token || data.token,
                    ...userData // Preservar otros campos
                };
                
                if (normalizedUser.token) {
                    localStorage.setItem('authToken', normalizedUser.token);
                }
                
                console.log('✅ Login exitoso con backend real (normalizado):', normalizedUser);
                return normalizedUser;
            } else {
                console.error('❌ Respuesta de login sin datos válidos:', data);
                throw new Error(data.message || data.error || 'Error en el login - estructura de respuesta no reconocida');
            }
        } catch (error) {
            console.error('💥 Error completo en login:', error);
            
            // Diagnosticar el tipo de error específico
            if (error.name === 'TypeError' && error.message.includes('fetch')) {
                const detailedError = new Error(`Error de conexión: No se puede conectar al backend en ${this.baseURL}${API_CONFIG.ENDPOINTS.LOGIN}. Verificar que el backend esté ejecutándose en puerto 3000 y que CORS esté configurado para http://localhost:5173`);
                console.error('🔍 Diagnóstico:', detailedError.message);
                throw detailedError;
            }
            
            throw error;
        }
    }

    async logout() {
        if (!this.useRealBackend) {
            await simulateNetworkDelay(200);
            localStorage.removeItem('authToken');
            localStorage.removeItem('user');
            return { success: true };
        }

        try {
            await this.makeRequest(API_CONFIG.ENDPOINTS.LOGOUT, {
                method: 'POST',
            });
        } finally {
            localStorage.removeItem('authToken');
            localStorage.removeItem('user');
        }
    }

    // === PRODUCTOS ===
    
    async getProductos() {
        if (!this.useRealBackend) {
            await simulateNetworkDelay();
            console.log('📦 Obteniendo productos mock:', MOCK_DATA.PRODUCTOS.length, 'productos');
            return MOCK_DATA.PRODUCTOS;
        }

        console.log('🌐 Obteniendo productos del backend real...');
        try {
            const response = await this.makeRequest(API_CONFIG.ENDPOINTS.PRODUCTOS);
            console.log('✅ Productos obtenidos del backend:', response);
            
            // Manejar diferentes estructuras de respuesta
            if (Array.isArray(response)) {
                return response;
            } else if (response.data && Array.isArray(response.data)) {
                return response.data;
            } else if (response.productos && Array.isArray(response.productos)) {
                return response.productos;
            } else {
                console.warn('⚠️ Estructura de respuesta inesperada:', response);
                return response;
            }
        } catch (error) {
            console.error('❌ Error al obtener productos del backend:', error);
            throw error;
        }
    }

    async getProductoById(id) {
        if (!this.useRealBackend) {
            await simulateNetworkDelay();
            const producto = MOCK_DATA.PRODUCTOS.find(p => p.id === parseInt(id));
            if (!producto) {
                throw new Error('Producto no encontrado');
            }
            return producto;
        }

        return await this.makeRequest(API_CONFIG.ENDPOINTS.PRODUCTO_BY_ID(id));
    }

    async createProducto(productoData) {
        if (!this.useRealBackend) {
            await simulateNetworkDelay();
            const nuevoProducto = {
                ...productoData,
                id: Math.max(...MOCK_DATA.PRODUCTOS.map(p => p.id)) + 1,
                fecha_creacion: new Date().toISOString().split('T')[0],
                estado: 'activo'
            };
            MOCK_DATA.PRODUCTOS.push(nuevoProducto);
            console.log('✅ Producto creado en modo mock:', nuevoProducto);
            return nuevoProducto;
        }

        console.log('🌐 Creando producto en backend real:', productoData);
        try {
            const response = await this.makeRequest(API_CONFIG.ENDPOINTS.PRODUCTOS, {
                method: 'POST',
                body: JSON.stringify(productoData),
            });
            console.log('✅ Producto creado en backend real:', response);
            return response;
        } catch (error) {
            console.error('❌ Error al crear producto en backend:', error);
            throw error;
        }
    }

    async updateProducto(id, productoData) {
        if (!this.useRealBackend) {
            await simulateNetworkDelay();
            const index = MOCK_DATA.PRODUCTOS.findIndex(p => p.id === parseInt(id));
            if (index === -1) {
                throw new Error('Producto no encontrado');
            }
            MOCK_DATA.PRODUCTOS[index] = { ...MOCK_DATA.PRODUCTOS[index], ...productoData };
            return MOCK_DATA.PRODUCTOS[index];
        }

        return await this.makeRequest(API_CONFIG.ENDPOINTS.PRODUCTO_BY_ID(id), {
            method: 'PUT',
            body: JSON.stringify(productoData),
        });
    }

    async deleteProducto(id) {
        if (!this.useRealBackend) {
            await simulateNetworkDelay();
            const index = MOCK_DATA.PRODUCTOS.findIndex(p => p.id === parseInt(id));
            if (index === -1) {
                throw new Error('Producto no encontrado');
            }
            const deletedProduct = MOCK_DATA.PRODUCTOS.splice(index, 1)[0];
            console.log('✅ Producto eliminado en modo mock:', deletedProduct);
            return { success: true };
        }

        console.log('🌐 Eliminando producto del backend real:', id);
        try {
            const response = await this.makeRequest(API_CONFIG.ENDPOINTS.PRODUCTO_BY_ID(id), {
                method: 'DELETE',
            });
            console.log('✅ Producto eliminado del backend real:', response);
            return response;
        } catch (error) {
            console.error('❌ Error al eliminar producto del backend:', error);
            throw error;
        }
    }

    // === USUARIOS ===
    
    async getUsuarios() {
        if (!this.useRealBackend) {
            await simulateNetworkDelay();
            return MOCK_DATA.USUARIOS;
        }

        console.log('🔍 Intentando obtener usuarios desde:', `${this.baseURL}/usuarios`);
        
        try {
            const response = await this.makeRequest(API_CONFIG.ENDPOINTS.USUARIOS);
            console.log('✅ Usuarios obtenidos correctamente:', response);
            return response;
        } catch (error) {
            console.error('❌ Error al obtener usuarios:', error);
            console.error('🔧 Detalles:', {
                endpoint: `${this.baseURL}${API_CONFIG.ENDPOINTS.USUARIOS}`,
                method: 'GET',
                useRealBackend: this.useRealBackend
            });
            throw error;
        }
    }

    async getUsuarioById(id) {
        if (!this.useRealBackend) {
            await simulateNetworkDelay();
            const usuario = MOCK_DATA.USUARIOS.find(u => u.id === parseInt(id));
            if (!usuario) {
                throw new Error('Usuario no encontrado');
            }
            return usuario;
        }

        return await this.makeRequest(API_CONFIG.ENDPOINTS.USUARIO_BY_ID(id));
    }

    async createUsuario(usuarioData) {
        if (!this.useRealBackend) {
            await simulateNetworkDelay();
            
            console.log('👤 Creando usuario mock con datos:', usuarioData);
            
            const nuevoUsuario = {
                ...usuarioData,
                id: Math.max(...MOCK_DATA.USUARIOS.map(u => u.id)) + 1,
                fecha_creacion: new Date().toISOString().split('T')[0],
                ultimoAcceso: null,
                // Mantener el formato correcto del estado (minúsculas)
                estado: usuarioData.estado || 'activo'
            };
            
            MOCK_DATA.USUARIOS.push(nuevoUsuario);
            console.log('✅ Usuario mock creado:', nuevoUsuario);
            console.log('📊 Total usuarios mock:', MOCK_DATA.USUARIOS.length);
            
            return nuevoUsuario;
        }

        console.log('🌐 Creando usuario en backend real:', usuarioData);
        
        return await this.makeRequest(API_CONFIG.ENDPOINTS.CREAR_USUARIO_ADMIN, {
            method: 'POST',
            body: JSON.stringify(usuarioData),
        });
    }

    async updateUsuario(id, usuarioData) {
        if (!this.useRealBackend) {
            await simulateNetworkDelay();
            const index = MOCK_DATA.USUARIOS.findIndex(u => u.id === parseInt(id));
            if (index === -1) {
                throw new Error('Usuario no encontrado');
            }
            
            console.log('🔄 Actualizando usuario mock:', id, usuarioData);
            
            // Actualizar el usuario manteniendo el formato correcto
            const usuarioActualizado = { 
                ...MOCK_DATA.USUARIOS[index], 
                ...usuarioData,
                // Mantener campos que no se deben cambiar
                id: MOCK_DATA.USUARIOS[index].id,
                fecha_creacion: MOCK_DATA.USUARIOS[index].fecha_creacion
            };
            
            MOCK_DATA.USUARIOS[index] = usuarioActualizado;
            console.log('✅ Usuario mock actualizado:', usuarioActualizado);
            
            return usuarioActualizado;
        }

        console.log('🌐 Actualizando usuario en backend real:', id, usuarioData);
        
        return await this.makeRequest(API_CONFIG.ENDPOINTS.USUARIO_BY_ID(id), {
            method: 'PUT',
            body: JSON.stringify(usuarioData),
        });
    }

    async deleteUsuario(id) {
        if (!this.useRealBackend) {
            await simulateNetworkDelay();
            const index = MOCK_DATA.USUARIOS.findIndex(u => u.id === parseInt(id));
            if (index === -1) {
                throw new Error('Usuario no encontrado');
            }
            
            console.log('🗑️ Inhabilitando usuario mock:', id);
            
            // En lugar de eliminar, marcar como inactivo (formato correcto)
            MOCK_DATA.USUARIOS[index].estado = 'inactivo';
            
            console.log('✅ Usuario inhabilitado:', MOCK_DATA.USUARIOS[index]);
            
            return { success: true };
        }

        console.log('🌐 Inhabilitando usuario en backend real:', id);
        
        return await this.makeRequest(API_CONFIG.ENDPOINTS.USUARIO_BY_ID(id), {
            method: 'DELETE',
        });
    }

    // === CATEGORÍAS ===
    
    async getCategorias() {
        if (!this.useRealBackend) {
            await simulateNetworkDelay();
            return MOCK_DATA.CATEGORIAS;
        }

        return await this.makeRequest(API_CONFIG.ENDPOINTS.CATEGORIAS);
    }

    // === CONFIGURACIÓN ===
    
    // Método para cambiar entre modo desarrollo y producción
    setBackendMode(useRealBackend) {
        this.useRealBackend = useRealBackend;
        // Guardar en localStorage para persistencia
        localStorage.setItem('kebumy_backend_mode', JSON.stringify(useRealBackend));
        // Sincronizar con configuración global
        API_CONFIG.USE_REAL_BACKEND = useRealBackend;
        console.log(`🔄 Modo backend cambiado a: ${useRealBackend ? 'REAL (Puerto 3000)' : 'MOCK (Desarrollo)'}`);
    }

    // Verificar estado de conexión con el backend
    async checkBackendHealth() {
        if (!this.useRealBackend) {
            return { 
                status: 'OK', 
                mode: 'DESARROLLO',
                message: 'Usando datos mock para desarrollo'
            };
        }

        try {
            // Usar la URL específica de health check
            const healthUrl = API_CONFIG.HEALTH_CHECK_URL || `${this.baseURL}/health`;
            const response = await fetch(healthUrl, {
                method: 'GET',
                headers: {
                    'Accept': 'application/json',
                },
                mode: 'cors',
            });

            if (response.ok) {
                const data = await response.json();
                return {
                    status: data.status || 'OK',
                    mode: 'PRODUCCIÓN',
                    message: data.message || 'Backend conectado correctamente',
                    backend_url: data.backend_url,
                    frontend_url: data.frontend_url,
                    timestamp: data.timestamp
                };
            } else {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }
        } catch (error) {
            console.error('Error checking backend health:', error);
            
            return {
                status: 'ERROR',
                mode: 'PRODUCCIÓN',
                error: `No se puede conectar al backend: ${error.message}`,
                details: `Verifique que el health check esté disponible en ${API_CONFIG.HEALTH_CHECK_URL}`
            };
        }
    }

    // Método para probar la conexión básica
    async testConnection() {
        try {
            console.log('🔍 Iniciando test de conexión completa...');
            
            // 1. Probar health check
            const healthUrl = API_CONFIG.HEALTH_CHECK_URL || `${this.baseURL}/health`;
            console.log('1️⃣ Probando health check:', healthUrl);
            
            const healthResponse = await fetch(healthUrl, {
                method: 'GET',
                headers: { 'Accept': 'application/json' },
                mode: 'cors',
            });
            
            console.log('✅ Health check status:', healthResponse.status);
            const healthData = await healthResponse.json();
            console.log('✅ Health check response:', healthData);
            
            // 2. Probar endpoint de usuarios
            console.log('2️⃣ Probando endpoint usuarios:', `${this.baseURL}/usuarios`);
            
            const usuariosResponse = await fetch(`${this.baseURL}/usuarios`, {
                method: 'GET',
                headers: { 
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                },
                mode: 'cors',
            });
            
            console.log('📊 Usuarios response status:', usuariosResponse.status);
            console.log('📊 Usuarios response headers:', [...usuariosResponse.headers.entries()]);
            
            if (usuariosResponse.ok) {
                const usuariosData = await usuariosResponse.json();
                console.log('✅ Usuarios data:', usuariosData);
                
                return {
                    healthCheck: healthData,
                    usuariosEndpoint: {
                        status: usuariosResponse.status,
                        data: usuariosData
                    },
                    message: '🎉 Conexión completa verificada correctamente'
                };
            } else {
                const errorText = await usuariosResponse.text().catch(() => 'No response body');
                console.error('❌ Error en endpoint usuarios:', errorText);
                
                return {
                    healthCheck: healthData,
                    usuariosEndpoint: {
                        status: usuariosResponse.status,
                        error: errorText
                    },
                    message: `⚠️ Health check OK, pero endpoint usuarios falló con status ${usuariosResponse.status}`
                };
            }
        } catch (error) {
            console.error('💥 Error general en test de conexión:', error);
            
            // Diagnosticar el tipo de error
            if (error.name === 'TypeError' && error.message.includes('fetch')) {
                return {
                    error: 'CORS o conexión rechazada',
                    details: 'El backend no permite conexiones desde este origen o no está disponible',
                    suggestion: 'Verificar configuración CORS para http://localhost:5173'
                };
            }
            
            throw error;
        }
    }
}

// Crear instancia única del servicio
const apiService = new ApiService();

export default apiService;