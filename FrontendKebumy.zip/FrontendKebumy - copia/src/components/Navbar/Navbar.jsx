import { Link, useNavigate } from 'react-router-dom';
import useAuth from '../../hooks/useAuth';
import logoKebumy from '../../assets/logoKebumy.png';
import logoMenu from '../../assets/Logo_menu.png';
import logoInicioSesion from '../../assets/logo_inicio_sesion.png';

export function Navbar() {
  const { user, isAuthenticated, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/', { replace: true });
  };

  return (
    <>
      {/* Top Banner */}
      <div className="top-banner">
        Bienvenido a Kebumy - Diseños únicos para ocasiones especiales
        <a href="/contacto">Contáctanos</a>
      </div>
      
      {/* Main Navbar */}
      <nav className="navbar">
        {/* Logo */}
        <div className="logo-container">
          <Link to="/">
            <img src={logoKebumy} alt="Kebumy Logo" />
          </Link>
        </div>

        {/* Navigation Links */}
        <div className="navbar-links">
          <Link to="/">Inicio</Link>
          {isAuthenticated && (
            <>
              <Link to="/inventario">Inventario</Link>
              <Link to="/admin-usuarios">Usuarios</Link>
            </>
          )}
          <Link to="/contacto">Contacto</Link>
        </div>

        {/* Right Side Icons */}
        <div className="navbar-icons">
          {isAuthenticated ? (
            <>
              <span style={{ marginRight: '15px', color: '#b0417a', fontSize: '14px' }}>
                Hola, {user.name || user.email}
              </span>
              <button 
                onClick={handleLogout}
                style={{
                  background: 'none',
                  border: 'none',
                  cursor: 'pointer',
                  color: '#b0417a',
                  fontSize: '14px',
                  textDecoration: 'underline'
                }}
              >
                Cerrar Sesión
              </button>
            </>
          ) : (
            <Link to="/login">
              <img 
                src={logoInicioSesion} 
                alt="Iniciar Sesión" 
                className="navbar-icon-img"
                title="Iniciar Sesión"
              />
            </Link>
          )}
          
          {/* Menu Toggle for Mobile */}
          <button className="menu-toggle-btn" style={{ display: 'none' }}>
            <span></span>
            <span></span>
            <span></span>
          </button>
        </div>
      </nav>
    </>
  );
}