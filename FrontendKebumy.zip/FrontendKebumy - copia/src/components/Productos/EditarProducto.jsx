import React, { useState, useEffect } from 'react';
import apiService from '../../services/apiService';

export default function EditarProducto({ 
    producto, 
    onClose, 
    onUpdateSuccess 
}) {
    const [formData, setFormData] = useState({
        nombre: '',
        descripcion: '',
        precio: '',
        stock: '',
        categoria_nombre: '',
        imagen_url: '',
        estado: 'activo'
    });
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);

    // Cargar datos del producto cuando se abre el modal
    useEffect(() => {
        if (producto) {
            setFormData({
                nombre: producto.nombre || '',
                descripcion: producto.descripcion || '',
                precio: producto.precio || '',
                stock: producto.stock || '',
                categoria_nombre: producto.categoria_nombre || '',
                imagen_url: producto.imagen_url || '',
                estado: producto.estado || 'activo'
            });
        }
    }, [producto]);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({
            ...prev,
            [name]: value
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        setError(null);

        // Validaciones
        if (!formData.nombre.trim() || !formData.descripcion.trim()) {
            setError('Nombre y descripción son obligatorios.');
            setLoading(false);
            return;
        }

        if (isNaN(formData.precio) || formData.precio < 0) {
            setError('El precio debe ser un número positivo.');
            setLoading(false);
            return;
        }

        if (isNaN(formData.stock) || formData.stock < 0) {
            setError('El stock debe ser un número positivo.');
            setLoading(false);
            return;
        }

        try {
            console.log('🔄 Actualizando producto:', producto.id, formData);
            
            const dataToSend = {
                ...formData,
                precio: Number(formData.precio),
                stock: Number(formData.stock)
            };

            await apiService.updateProducto(producto.id, dataToSend);
            
            console.log('✅ Producto actualizado exitosamente');
            
            if (onUpdateSuccess) {
                onUpdateSuccess();
            }
            
            onClose();
        } catch (err) {
            console.error('❌ Error al actualizar producto:', err);
            setError(err.message || 'Error al actualizar producto');
        } finally {
            setLoading(false);
        }
    };

    if (!producto) return null;

    return (
        <div className="modal show d-block" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}>
            <div className="modal-dialog modal-lg">
                <div className="modal-content">
                    <div className="modal-header" style={{ backgroundColor: '#b0417a', color: 'white' }}>
                        <h5 className="modal-title">
                            <i className="fas fa-edit me-2"></i>
                            Editar Producto
                        </h5>
                        <button 
                            type="button" 
                            className="btn-close btn-close-white" 
                            onClick={onClose}
                            disabled={loading}
                        ></button>
                    </div>
                    
                    <div className="modal-body">
                        {error && (
                            <div className="alert alert-danger" role="alert">
                                <i className="fas fa-exclamation-triangle me-2"></i>
                                {error}
                            </div>
                        )}

                        <form onSubmit={handleSubmit}>
                            <div className="row">
                                <div className="col-md-6">
                                    <div className="mb-3">
                                        <label className="form-label">
                                            <i className="fas fa-tag me-1"></i>
                                            Nombre *
                                        </label>
                                        <input
                                            type="text"
                                            className="form-control"
                                            name="nombre"
                                            value={formData.nombre}
                                            onChange={handleChange}
                                            required
                                            disabled={loading}
                                        />
                                    </div>
                                </div>

                                <div className="col-md-6">
                                    <div className="mb-3">
                                        <label className="form-label">
                                            <i className="fas fa-layer-group me-1"></i>
                                            Categoría *
                                        </label>
                                        <select
                                            className="form-control"
                                            name="categoria_nombre"
                                            value={formData.categoria_nombre}
                                            onChange={handleChange}
                                            required
                                            disabled={loading}
                                        >
                                            <option value="">Seleccionar categoría</option>
                                            <option value="Para ti">Para ti</option>
                                            <option value="Para marcas">Para marcas</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div className="mb-3">
                                <label className="form-label">
                                    <i className="fas fa-align-left me-1"></i>
                                    Descripción *
                                </label>
                                <textarea
                                    className="form-control"
                                    name="descripcion"
                                    value={formData.descripcion}
                                    onChange={handleChange}
                                    rows="3"
                                    required
                                    disabled={loading}
                                />
                            </div>

                            <div className="row">
                                <div className="col-md-4">
                                    <div className="mb-3">
                                        <label className="form-label">
                                            <i className="fas fa-dollar-sign me-1"></i>
                                            Precio *
                                        </label>
                                        <input
                                            type="number"
                                            className="form-control"
                                            name="precio"
                                            value={formData.precio}
                                            onChange={handleChange}
                                            min="0"
                                            step="0.01"
                                            required
                                            disabled={loading}
                                        />
                                    </div>
                                </div>

                                <div className="col-md-4">
                                    <div className="mb-3">
                                        <label className="form-label">
                                            <i className="fas fa-boxes me-1"></i>
                                            Stock *
                                        </label>
                                        <input
                                            type="number"
                                            className="form-control"
                                            name="stock"
                                            value={formData.stock}
                                            onChange={handleChange}
                                            min="0"
                                            required
                                            disabled={loading}
                                        />
                                    </div>
                                </div>

                                <div className="col-md-4">
                                    <div className="mb-3">
                                        <label className="form-label">
                                            <i className="fas fa-toggle-on me-1"></i>
                                            Estado
                                        </label>
                                        <select
                                            className="form-control"
                                            name="estado"
                                            value={formData.estado}
                                            onChange={handleChange}
                                            disabled={loading}
                                        >
                                            <option value="activo">Activo</option>
                                            <option value="inactivo">Inactivo</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div className="mb-3">
                                <label className="form-label">
                                    <i className="fas fa-image me-1"></i>
                                    URL de Imagen
                                </label>
                                <input
                                    type="url"
                                    className="form-control"
                                    name="imagen_url"
                                    value={formData.imagen_url}
                                    onChange={handleChange}
                                    placeholder="https://ejemplo.com/imagen.jpg"
                                    disabled={loading}
                                />
                                <small className="form-text text-muted">
                                    Ingresa la URL completa de la imagen del producto
                                </small>
                            </div>

                            <div className="d-flex justify-content-end gap-2">
                                <button
                                    type="button"
                                    className="btn btn-secondary"
                                    onClick={onClose}
                                    disabled={loading}
                                >
                                    <i className="fas fa-times me-1"></i>
                                    Cancelar
                                </button>
                                <button
                                    type="submit"
                                    className="btn"
                                    style={{ backgroundColor: '#b0417a', color: 'white' }}
                                    disabled={loading}
                                >
                                    {loading ? (
                                        <>
                                            <i className="fas fa-spinner fa-spin me-1"></i>
                                            Actualizando...
                                        </>
                                    ) : (
                                        <>
                                            <i className="fas fa-save me-1"></i>
                                            Actualizar Producto
                                        </>
                                    )}
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    );
}