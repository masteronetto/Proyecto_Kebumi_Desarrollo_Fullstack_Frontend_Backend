import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import apiService from '../../services/apiService';
import EditarProducto from './EditarProducto';

// Importar todas las imágenes necesarias
import PolerImg from '../../assets/Polera.png';
import PoleronImg from '../../assets/Poleron.png';
import AgendaImg from '../../assets/Agenda.png';
import StickerImg from '../../assets/sticker.png';
import PolaroidImg from '../../assets/Polaroid.png';
import MiniCalendarioImg from '../../assets/miniCalendario.png';
import PolerasMarcaImg from '../../assets/PolerasMarca.png';
import TarjetaPresentacionImg from '../../assets/TarjetaPresentacion2.jpeg';
import EtiquetaCueroImg from '../../assets/etiquetaCuero.png';
import Sticker3Img from '../../assets/Sticker3.png';
import KitCumpleanosImg from '../../assets/KitCumpleaños.png';
import ImagenProducto1 from '../../assets/imagen producto 1.webp';

// Helper para obtener la URL correcta de la imagen
const getImageUrl = (imagenUrl, productName = '') => {
    // Mapeo de imágenes del backend a las importadas
    const imageMap = {
        'img/Polera.png': PolerImg,
        'img/Poleron.png': PoleronImg,
        'img/Agenda.png': AgendaImg,
        'img/sticker.png': StickerImg,
        'img/Polaroid.png': PolaroidImg,
        'img/miniCalendario.png': MiniCalendarioImg,
        'img/PolerasMarca.png': PolerasMarcaImg,
        'img/tarjetaPresentacion.png': TarjetaPresentacionImg,
        'img/etiquetaCuero.png': EtiquetaCueroImg,
        'img/stickerMarca.png': Sticker3Img,
        'img/Mochila.png': KitCumpleanosImg
    };
    
    // Si no hay imagen_url, usar imagen por defecto
    if (!imagenUrl) {
        return ImagenProducto1;
    }
    
    // Si la URL ya es absoluta (http/https), usarla directamente
    if (imagenUrl.startsWith('http')) {
        return imagenUrl;
    }
    
    // Usar el mapeo para convertir URLs del backend
    if (imageMap[imagenUrl]) {
        console.log(`🖼️ Mapeando imagen: ${imagenUrl} → imagen importada`);
        return imageMap[imagenUrl];
    }
    
    // Si es una URL relativa, buscar en el mapeo
    if (imagenUrl.startsWith('img/')) {
        console.log(`🔄 Imagen encontrada en mapeo: ${imagenUrl}`);
        return imageMap[imagenUrl] || ImagenProducto1;
    }
    
    // Fallback por defecto
    console.log(`⚠️ Imagen no encontrada: ${imagenUrl}, usando imagen por defecto`);
    return ImagenProducto1;
};

export function Productos() {
    const [productos, setProductos] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [productoEditando, setProductoEditando] = useState(null);
    const [mostrarModalEditar, setMostrarModalEditar] = useState(false);

    const fetchProductos = async () => {
        setLoading(true);
        setError(null);
        
        console.log('🔍 Fetching productos...');
        console.log('🔧 Estado del apiService:', {
            useRealBackend: apiService.useRealBackend,
            baseURL: apiService.baseURL
        });
        
        try {
            const data = await apiService.getProductos();
            console.log('✅ Productos obtenidos:', data);
            setProductos(data);
        } catch (error) {
            console.error('❌ Error al cargar productos:', error);
            console.error('🔍 Detalles del error:', {
                name: error.name,
                message: error.message,
                stack: error.stack
            });
            setError(error.message || 'No se pudo cargar el inventario.');
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        console.log('🚀 Productos component montado, iniciando carga...');
        fetchProductos();
    }, []);

    // Detectar cambios en el modo backend
    useEffect(() => {
        const checkBackendMode = () => {
            const savedMode = localStorage.getItem('kebumy_backend_mode');
            if (savedMode !== null) {
                const isReal = JSON.parse(savedMode);
                if (apiService.useRealBackend !== isReal) {
                    console.log('🔄 Cambio detectado en modo backend, recargando productos...');
                    apiService.setBackendMode(isReal);
                    fetchProductos();
                }
            }
        };

        // Verificar cambios cada 2 segundos
        const interval = setInterval(checkBackendMode, 2000);
        return () => clearInterval(interval);
    }, []);

    // Lógica de Eliminación (DELETE)
    const handleDelete = async (id) => {
        if (!window.confirm(`¿Está seguro de eliminar el producto ID: ${id}?`)) return;

        try {
            await apiService.deleteProducto(id);
            await fetchProductos(); // Recargar la lista
            alert('Producto eliminado correctamente');
        } catch (error) {
            console.error('Error al eliminar producto:', error);
            alert('Error al eliminar el producto: ' + error.message);
        }
    };

    // Lógica de Edición (UPDATE)
    const handleEdit = (producto) => {
        console.log('🔄 Editando producto:', producto);
        setProductoEditando(producto);
        setMostrarModalEditar(true);
    };

    const handleCloseEditModal = () => {
        setMostrarModalEditar(false);
        setProductoEditando(null);
    };

    const handleUpdateSuccess = async () => {
        console.log('✅ Producto actualizado, recargando lista...');
        await fetchProductos(); // Recargar la lista
    };

    if (loading) return (
        <div style={{ textAlign: 'center', padding: '40px' }}>
            <p style={{ color: '#555', fontSize: '1.2em' }}>Cargando inventario...</p>
        </div>
    );
    
    if (error) return (
        <div style={{ 
            backgroundColor: '#f8d7da', 
            color: '#721c24', 
            padding: '20px', 
            borderRadius: '5px', 
            margin: '20px 0',
            border: '1px solid #f5c6cb'
        }}>
            {error}
        </div>
    );

    return (
        <div className="admin-products-container">
            {/* Indicador de Estado de Conexión */}
            <div style={{
                backgroundColor: apiService.useRealBackend ? '#d4edda' : '#fff3cd',
                color: apiService.useRealBackend ? '#155724' : '#856404',
                padding: '10px 15px',
                borderRadius: '5px',
                marginBottom: '15px',
                border: `1px solid ${apiService.useRealBackend ? '#c3e6cb' : '#ffeaa7'}`,
                fontSize: '14px'
            }}>
                <strong>🔗 Estado:</strong> {apiService.useRealBackend ? 
                    '🌐 Backend Real (Puerto 3000)' : 
                    '🧪 Modo Mock (Desarrollo)'
                }
                {apiService.useRealBackend && (
                    <span style={{ marginLeft: '10px', fontSize: '12px', opacity: 0.8 }}>
                        • Backend debe estar activo
                    </span>
                )}
            </div>

            <div className="products-header">
                <h3 style={{ color: '#555', margin: 0 }}>Inventario de Productos</h3>
                <div style={{ display: 'flex', gap: '10px' }}>
                    <button
                        onClick={fetchProductos}
                        disabled={loading}
                        style={{
                            backgroundColor: '#6c757d',
                            color: 'white',
                            padding: '8px 16px',
                            borderRadius: '15px',
                            border: 'none',
                            fontSize: '0.8em',
                            cursor: loading ? 'not-allowed' : 'pointer',
                            opacity: loading ? 0.6 : 1
                        }}
                        title="Recargar productos"
                    >
                        🔄 {loading ? 'Cargando...' : 'Recargar'}
                    </button>
                    <Link 
                        to="/crear-producto"
                        style={{
                            backgroundColor: '#b0417a',
                            color: 'white',
                            padding: '10px 20px',
                            borderRadius: '20px',
                            textDecoration: 'none',
                            fontSize: '0.9em'
                        }}
                    >
                        + Crear Producto
                    </Link>
                </div>
            </div>

            <div className="products-list">
                {productos.map(prod => (
                    <div key={prod.id} className="product-card-admin">
                        <div className="product-image-admin">
                            <img 
                                src={getImageUrl(prod.imagen_url, prod.nombre)} 
                                alt={prod.nombre}
                                onError={(e) => {
                                    console.log(`❌ Error cargando imagen para "${prod.nombre}":`, {
                                        imagenOriginal: prod.imagen_url,
                                        imagenProcesada: getImageUrl(prod.imagen_url, prod.nombre),
                                        producto: prod.nombre
                                    });
                                    e.target.src = '/src/assets/imagen producto 1.webp';
                                }}
                                onLoad={() => {
                                    console.log(`✅ Imagen cargada correctamente para "${prod.nombre}":`, getImageUrl(prod.imagen_url, prod.nombre));
                                }}
                            />
                        </div>
                        <div className="product-details-admin">
                            <h4 className="product-name-admin">{prod.nombre}</h4>
                            <p className="product-stock" style={{
                                color: prod.stock < 5 ? '#dc3545' : '#28a745',
                                fontWeight: prod.stock < 5 ? 'bold' : 'normal'
                            }}>
                                Stock: {prod.stock} unidades
                                {prod.stock < 5 && <span style={{ marginLeft: '8px' }}>⚠️ STOCK BAJO</span>}
                            </p>
                            <p className="product-description-admin">{prod.descripcion}</p>
                            <p className="product-category" style={{ 
                                fontSize: '0.9em', 
                                color: '#666',
                                fontStyle: 'italic'
                            }}>
                                📂 {prod.categoria_nombre}
                            </p>
                        </div>
                        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '10px' }}>
                            <p className="product-price-admin">
                                ${typeof prod.precio === 'number' ? prod.precio.toLocaleString('es-CL') : 'N/A'}
                            </p>
                            <div className="product-actions">
                                <button 
                                    className="action-btn"
                                    title="Editar producto"
                                    onClick={() => handleEdit(prod)}
                                >
                                    ✏️
                                </button>
                                <button 
                                    className="action-btn delete-btn"
                                    title="Eliminar producto"
                                    onClick={() => handleDelete(prod.id)}
                                >
                                    🗑️
                                </button>
                            </div>
                        </div>
                    </div>
                ))}
            </div>
            
            {productos.length === 0 && (
                <div style={{ 
                    textAlign: 'center', 
                    padding: '40px',
                    backgroundColor: '#e8e2d8',
                    borderRadius: '12px',
                    margin: '20px 0'
                }}>
                    <p style={{ color: '#555', fontSize: '1.1em' }}>
                        No hay productos en el inventario.
                    </p>
                    <Link 
                        to="/crear-producto"
                        style={{
                            backgroundColor: '#925c93',
                            color: 'white',
                            padding: '12px 30px',
                            borderRadius: '20px',
                            textDecoration: 'none',
                            fontSize: '1em'
                        }}
                    >
                        Crear primer producto
                    </Link>
                </div>
            )}

            {/* Modal de Edición */}
            {mostrarModalEditar && (
                <EditarProducto
                    producto={productoEditando}
                    onClose={handleCloseEditModal}
                    onUpdateSuccess={handleUpdateSuccess}
                />
            )}
        </div>
    );
}