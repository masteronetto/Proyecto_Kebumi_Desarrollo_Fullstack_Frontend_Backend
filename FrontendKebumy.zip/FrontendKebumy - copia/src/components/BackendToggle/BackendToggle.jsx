// src/components/BackendToggle/BackendToggle.jsx
// Componente para alternar entre modo desarrollo y producción

import React, { useState, useEffect, useRef } from 'react';
import apiService from '../../services/apiService';
import { API_CONFIG } from '../../config/api';
import DiagnosticTool from '../DiagnosticTool/DiagnosticTool';

export function BackendToggle() {
    // Inicializar desde localStorage para persistencia
    const [useRealBackend, setUseRealBackend] = useState(() => {
        const saved = localStorage.getItem('kebumy_backend_mode');
        if (saved !== null) {
            const isReal = JSON.parse(saved);
            // Sincronizar con API_CONFIG y apiService
            API_CONFIG.USE_REAL_BACKEND = isReal;
            apiService.setBackendMode(isReal);
            return isReal;
        }
        return API_CONFIG.USE_REAL_BACKEND;
    });
    
    const [backendHealth, setBackendHealth] = useState(null);
    const [checking, setChecking] = useState(false);
    const [isDragging, setIsDragging] = useState(false);
    const [position, setPosition] = useState(() => {
        const savedPosition = localStorage.getItem('kebumy_toggle_position');
        return savedPosition ? JSON.parse(savedPosition) : { x: 10, y: 10 };
    });
    const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
    const [showDiagnostic, setShowDiagnostic] = useState(false);
    const toggleRef = useRef(null);

    // Efecto para sincronizar cambios externos
    useEffect(() => {
        const interval = setInterval(() => {
            if (apiService.useRealBackend !== useRealBackend) {
                console.log('🔄 Sincronizando estado del backend toggle');
                setUseRealBackend(apiService.useRealBackend);
            }
        }, 1000);

        return () => clearInterval(interval);
    }, [useRealBackend]);

    const checkBackendHealth = async () => {
        setChecking(true);
        try {
            const health = await apiService.checkBackendHealth();
            setBackendHealth(health);
        } catch (error) {
            setBackendHealth({ status: 'ERROR', error: error.message });
        } finally {
            setChecking(false);
        }
    };

    const toggleBackend = async () => {
        const newMode = !useRealBackend;
        console.log(`🔄 Cambiando backend: ${useRealBackend ? 'Real' : 'Mock'} → ${newMode ? 'Real' : 'Mock'}`);
        
        setUseRealBackend(newMode);
        apiService.setBackendMode(newMode);
        
        // Actualizar la configuración global
        API_CONFIG.USE_REAL_BACKEND = newMode;
        
        // Guardar en localStorage para persistencia
        localStorage.setItem('kebumy_backend_mode', JSON.stringify(newMode));
        
        console.log(`✅ Backend cambiado a: ${newMode ? 'Real (Puerto 3000)' : 'Mock (Datos de prueba)'}`);
        
        // Verificar el estado del backend
        await checkBackendHealth();
    };

    const handleMouseDown = (e) => {
        setIsDragging(true);
        const rect = toggleRef.current.getBoundingClientRect();
        setDragOffset({
            x: e.clientX - rect.left,
            y: e.clientY - rect.top
        });
    };

    const handleMouseMove = (e) => {
        if (isDragging) {
            const newX = e.clientX - dragOffset.x;
            const newY = e.clientY - dragOffset.y;
            
            // Limitar el movimiento dentro de la ventana
            const maxX = window.innerWidth - 250; // ancho del toggle
            const maxY = window.innerHeight - 200; // altura aproximada del toggle
            
            setPosition({
                x: Math.max(0, Math.min(newX, maxX)),
                y: Math.max(0, Math.min(newY, maxY))
            });
        }
    };

    const handleMouseUp = () => {
        setIsDragging(false);
        // Guardar posición en localStorage
        localStorage.setItem('kebumy_toggle_position', JSON.stringify(position));
    };

    useEffect(() => {
        if (isDragging) {
            document.addEventListener('mousemove', handleMouseMove);
            document.addEventListener('mouseup', handleMouseUp);
        }

        return () => {
            document.removeEventListener('mousemove', handleMouseMove);
            document.removeEventListener('mouseup', handleMouseUp);
        };
    }, [isDragging, dragOffset]);

    useEffect(() => {
        checkBackendHealth();
    }, [useRealBackend]);

    const getStatusColor = (status) => {
        switch (status) {
            case 'OK': return '#4CAF50';
            case 'ERROR': return '#F44336';
            default: return '#FF9800';
        }
    };

    return (
        <div 
            ref={toggleRef}
            style={{
                position: 'fixed',
                top: `${position.y}px`,
                left: `${position.x}px`,
                backgroundColor: 'white',
                border: '2px solid #b0417a',
                borderRadius: '8px',
                padding: '10px',
                zIndex: 1000,
                minWidth: '250px',
                boxShadow: '0 4px 12px rgba(176, 65, 122, 0.2)',
                cursor: isDragging ? 'grabbing' : 'grab',
                userSelect: 'none'
            }}
            onMouseDown={handleMouseDown}
        >
            <div style={{ 
                marginBottom: '10px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between'
            }}>
                <strong style={{ color: '#b0417a' }}>🔧 Modo Backend</strong>
                <span style={{ 
                    fontSize: '12px', 
                    color: '#925c93',
                    fontWeight: 'normal'
                }}>
                    📌 Arrastrable
                </span>
            </div>
            
            <div style={{ marginBottom: '10px' }}>
                <label style={{ display: 'flex', alignItems: 'center', cursor: 'pointer' }}>
                    <input
                        type="checkbox"
                        checked={useRealBackend}
                        onChange={toggleBackend}
                        style={{ marginRight: '8px' }}
                    />
                    <span>Usar Backend Real (MySQL)</span>
                </label>
            </div>

            {backendHealth && (
                <div style={{ 
                    fontSize: '12px', 
                    padding: '5px',
                    backgroundColor: '#f5f5f5',
                    borderRadius: '4px',
                    marginBottom: '8px'
                }}>
                    <div style={{ 
                        display: 'flex', 
                        alignItems: 'center',
                        marginBottom: '4px'
                    }}>
                        <div style={{
                            width: '8px',
                            height: '8px',
                            borderRadius: '50%',
                            backgroundColor: getStatusColor(backendHealth.status),
                            marginRight: '6px'
                        }}></div>
                        <span><strong>Estado:</strong> {backendHealth.status}</span>
                    </div>
                    <div><strong>Modo:</strong> {backendHealth.mode}</div>
                    {backendHealth.backend_url && (
                        <div><strong>Backend:</strong> {backendHealth.backend_url}</div>
                    )}
                    {backendHealth.frontend_url && (
                        <div><strong>Frontend:</strong> {backendHealth.frontend_url}</div>
                    )}
                    {backendHealth.message && (
                        <div style={{ color: '#4CAF50', marginTop: '4px' }}>
                            {backendHealth.message}
                        </div>
                    )}
                    {backendHealth.error && (
                        <div style={{ color: '#F44336', marginTop: '4px' }}>
                            <strong>Error:</strong> {backendHealth.error}
                        </div>
                    )}
                    {backendHealth.details && (
                        <div style={{ color: '#666', marginTop: '4px', fontSize: '10px' }}>
                            {backendHealth.details}
                        </div>
                    )}
                </div>
            )}

            <div style={{ marginBottom: '8px' }}>
                <button
                    onClick={checkBackendHealth}
                    disabled={checking}
                    style={{
                        backgroundColor: '#b0417a',
                        color: 'white',
                        border: 'none',
                        padding: '4px 8px',
                        borderRadius: '4px',
                        fontSize: '12px',
                        cursor: 'pointer',
                        width: '48%',
                        marginRight: '4%'
                    }}
                >
                    {checking ? 'Verificando...' : 'Verificar'}
                </button>

                <button
                    onClick={async () => {
                        if (useRealBackend) {
                            try {
                                const result = await apiService.testConnection();
                                console.log('Test connection result:', result);
                                alert('✅ Conexión exitosa! Ver consola para detalles.');
                            } catch (error) {
                                console.error('Test connection failed:', error);
                                alert(`❌ Error de conexión: ${error.message}`);
                            }
                        } else {
                            alert('ℹ️ Cambiar a modo backend real para probar conexión');
                        }
                    }}
                    disabled={checking || !useRealBackend}
                    style={{
                        backgroundColor: useRealBackend ? '#925c93' : '#ccc',
                        color: 'white',
                        border: 'none',
                        padding: '4px 8px',
                        borderRadius: '4px',
                        fontSize: '12px',
                        cursor: useRealBackend ? 'pointer' : 'not-allowed',
                        width: '48%'
                    }}
                >
                    Test
                </button>
                <button
                    onClick={() => setShowDiagnostic(true)}
                    style={{
                        backgroundColor: '#e8e2d8',
                        color: '#b0417a',
                        border: '1px solid #b0417a',
                        padding: '4px 8px',
                        borderRadius: '4px',
                        fontSize: '12px',
                        cursor: 'pointer',
                        width: '100%',
                        marginTop: '4px'
                    }}
                >
                    🔧 Diagnóstico Completo
                </button>
            </div>

            <div style={{ 
                fontSize: '10px', 
                color: '#666', 
                marginTop: '8px',
                textAlign: 'center'
            }}>
                {useRealBackend 
                    ? '📡 Conectado a Spring Boot + MySQL' 
                    : '🛠️ Usando datos de ejemplo'
                }
            </div>

            {/* Herramienta de diagnóstico */}
            {showDiagnostic && (
                <>
                    <div style={{
                        position: 'fixed',
                        top: 0,
                        left: 0,
                        right: 0,
                        bottom: 0,
                        backgroundColor: 'rgba(0,0,0,0.5)',
                        zIndex: 1999
                    }} onClick={() => setShowDiagnostic(false)} />
                    <DiagnosticTool onClose={() => setShowDiagnostic(false)} />
                </>
            )}
        </div>
    );
}

export default BackendToggle;