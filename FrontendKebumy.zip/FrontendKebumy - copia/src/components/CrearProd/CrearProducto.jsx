import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Navbar } from '../Navbar/Navbar';
import apiService from '../../services/apiService';

export default function CrearProducto() {
    const navigate = useNavigate();
    const [producto, setProducto] = useState({
        nombre: '',
        descripcion: '',
        precio: '',
        categoria_nombre: '',
        stock: '',
        imagen_url: '',
        estado: 'activo'
    });
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setProducto(prev => ({
            ...prev,
            [name]: value
        }));
    };

    const isValidUrl = (url) => {
        if (!url) return true;
        try {
            new URL(url);
            return true;
        } catch {
            return false;
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        setError(null);

        // Validación básica
        if (
            !producto.nombre.trim() ||
            !producto.descripcion.trim() ||
            !producto.precio ||
            !producto.categoria_nombre.trim() ||
            !producto.stock
        ) {
            setError('Todos los campos son obligatorios.');
            setLoading(false);
            return;
        }

        // Validación de precio y stock
        const precioNum = Number(producto.precio);
        const stockNum = Number(producto.stock);
        if (isNaN(precioNum) || precioNum < 0) {
            setError('El precio debe ser un número positivo.');
            setLoading(false);
            return;
        }
        if (isNaN(stockNum) || stockNum < 0) {
            setError('El stock debe ser un número positivo.');
            setLoading(false);
            return;
        }

        // Validación de imagen URL
        if (producto.imagen_url && !isValidUrl(producto.imagen_url)) {
            setError('La URL de la imagen no es válida.');
            setLoading(false);
            return;
        }

        const dataToSend = {
            ...producto,
            precio: precioNum,
            stock: stockNum
        };

        try {
            console.log('🔄 Creando producto:', dataToSend);
            await apiService.createProducto(dataToSend);
            
            console.log('✅ Producto creado exitosamente');
            
            // Limpiar formulario
            setProducto({
                nombre: '',
                descripcion: '',
                precio: '',
                categoria_nombre: '',
                stock: '',
                imagen_url: '',
                estado: 'activo'
            });
            
            navigate('/inventario');
        } catch (err) {
            console.error('❌ Error al crear producto:', err);
            setError(err.message || 'Error al crear producto');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="container">
            <Navbar />
            <h3 style={{ marginTop: '20px' }}>Crear Nuevo Producto</h3>
            {error && <div className="alert alert-danger mt-3">{error}</div>}
            <form onSubmit={handleSubmit} className="mt-4">
                <div className="mb-3">
                    <label className="form-label">Nombre</label>
                    <input
                        type="text"
                        className="form-control"
                        name="nombre"
                        value={producto.nombre}
                        onChange={handleChange}
                        required
                    />
                </div>
                <div className="mb-3">
                    <label className="form-label">Descripción</label>
                    <textarea
                        className="form-control"
                        name="descripcion"
                        value={producto.descripcion}
                        onChange={handleChange}
                        required
                    />
                </div>
                <div className="mb-3">
                    <label className="form-label">Precio</label>
                    <input
                        type="number"
                        className="form-control"
                        name="precio"
                        value={producto.precio}
                        onChange={handleChange}
                        min="0"
                        required
                    />
                </div>
                <div className="mb-3">
                    <label className="form-label">Stock</label>
                    <input
                        type="number"
                        className="form-control"
                        name="stock"
                        value={producto.stock}
                        onChange={handleChange}
                        min="0"
                        required
                    />
                </div>
                <div className="mb-3">
                    <label className="form-label">Categoría</label>
                    <select
                        className="form-control"
                        name="categoria_nombre"
                        value={producto.categoria_nombre}
                        onChange={handleChange}
                        required
                    >
                        <option value="">Seleccionar categoría</option>
                        <option value="Para ti">Para ti</option>
                        <option value="Para marcas">Para marcas</option>
                    </select>
                </div>
                <div className="mb-3">
                    <label className="form-label">Imagen URL</label>
                    <input
                        type="text"
                        className="form-control"
                        name="imagen_url"
                        value={producto.imagen_url}
                        onChange={handleChange}
                    />
                </div>
                <button type="submit" className="btn btn-success" disabled={loading}>
                    {loading ? 'Guardando...' : 'Guardar Producto'}
                </button>
            </form>
        </div>
    );
}