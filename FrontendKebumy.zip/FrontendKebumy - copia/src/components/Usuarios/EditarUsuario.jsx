// src/components/Usuarios/EditarUsuario.jsx
// Componente modal para editar usuarios

import React, { useState, useEffect } from 'react';
import apiService from '../../services/apiService';

export function EditarUsuario({ usuario, isOpen, onClose, onUsuarioActualizado }) {
    const [formData, setFormData] = useState({
        nombre: '',
        email: '',
        rol: '',
        estado: ''
    });
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');

    // Cargar datos del usuario cuando se abre el modal
    useEffect(() => {
        if (usuario && isOpen) {
            setFormData({
                nombre: usuario.nombre || '',
                email: usuario.email || '',
                rol: usuario.rol || '',
                estado: usuario.estado || 'activo'
            });
            setError('');
        }
    }, [usuario, isOpen]);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({
            ...prev,
            [name]: value
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        
        if (!formData.nombre.trim() || !formData.email.trim()) {
            setError('El nombre y email son obligatorios');
            return;
        }

        if (!/\S+@\S+\.\S+/.test(formData.email)) {
            setError('Por favor ingrese un email válido');
            return;
        }

        setLoading(true);
        setError('');

        try {
            console.log('🔄 Actualizando usuario:', usuario.id, formData);
            
            const usuarioActualizado = await apiService.updateUsuario(usuario.id, formData);
            
            console.log('✅ Usuario actualizado exitosamente:', usuarioActualizado);
            
            // Notificar al componente padre
            onUsuarioActualizado();
            
            // Cerrar modal
            onClose();
            
            alert('Usuario actualizado correctamente');
            
        } catch (error) {
            console.error('❌ Error al actualizar usuario:', error);
            setError(error.message || 'Error al actualizar el usuario');
        } finally {
            setLoading(false);
        }
    };

    const handleCancel = () => {
        setError('');
        onClose();
    };

    if (!isOpen) return null;

    return (
        <>
            {/* Overlay de fondo */}
            <div 
                style={{
                    position: 'fixed',
                    top: 0,
                    left: 0,
                    right: 0,
                    bottom: 0,
                    backgroundColor: 'rgba(0, 0, 0, 0.5)',
                    zIndex: 1000,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center'
                }}
                onClick={handleCancel}
            >
                {/* Modal */}
                <div 
                    style={{
                        backgroundColor: 'white',
                        borderRadius: '8px',
                        padding: '30px',
                        minWidth: '500px',
                        maxWidth: '90vw',
                        maxHeight: '90vh',
                        overflow: 'auto',
                        boxShadow: '0 8px 32px rgba(0,0,0,0.3)',
                        position: 'relative'
                    }}
                    onClick={(e) => e.stopPropagation()}
                >
                    {/* Header */}
                    <div style={{ 
                        marginBottom: '20px',
                        borderBottom: '2px solid #b0417a',
                        paddingBottom: '10px'
                    }}>
                        <h2 style={{ 
                            margin: 0, 
                            color: '#b0417a',
                            fontSize: '1.5em'
                        }}>
                            ✏️ Editar Usuario
                        </h2>
                        <p style={{ 
                            margin: '5px 0 0 0', 
                            color: '#666',
                            fontSize: '0.9em'
                        }}>
                            ID: {usuario?.id} | Modificando datos del usuario
                        </p>
                    </div>

                    {/* Formulario */}
                    <form onSubmit={handleSubmit}>
                        {error && (
                            <div style={{
                                backgroundColor: '#f8d7da',
                                color: '#721c24',
                                padding: '10px',
                                borderRadius: '5px',
                                marginBottom: '20px',
                                border: '1px solid #f5c6cb'
                            }}>
                                {error}
                            </div>
                        )}

                        <div style={{ marginBottom: '15px' }}>
                            <label style={{ 
                                display: 'block', 
                                marginBottom: '5px',
                                fontWeight: 'bold',
                                color: '#333'
                            }}>
                                Nombre Completo *
                            </label>
                            <input
                                type="text"
                                name="nombre"
                                value={formData.nombre}
                                onChange={handleChange}
                                required
                                disabled={loading}
                                style={{
                                    width: '100%',
                                    padding: '10px',
                                    border: '1px solid #ddd',
                                    borderRadius: '5px',
                                    fontSize: '16px',
                                    boxSizing: 'border-box'
                                }}
                                placeholder="Ej: Juan Pérez"
                            />
                        </div>

                        <div style={{ marginBottom: '15px' }}>
                            <label style={{ 
                                display: 'block', 
                                marginBottom: '5px',
                                fontWeight: 'bold',
                                color: '#333'
                            }}>
                                Email *
                            </label>
                            <input
                                type="email"
                                name="email"
                                value={formData.email}
                                onChange={handleChange}
                                required
                                disabled={loading}
                                style={{
                                    width: '100%',
                                    padding: '10px',
                                    border: '1px solid #ddd',
                                    borderRadius: '5px',
                                    fontSize: '16px',
                                    boxSizing: 'border-box'
                                }}
                                placeholder="Ej: juan@ejemplo.com"
                            />
                        </div>

                        <div style={{ marginBottom: '15px' }}>
                            <label style={{ 
                                display: 'block', 
                                marginBottom: '5px',
                                fontWeight: 'bold',
                                color: '#333'
                            }}>
                                Rol
                            </label>
                            <select
                                name="rol"
                                value={formData.rol}
                                onChange={handleChange}
                                disabled={loading}
                                style={{
                                    width: '100%',
                                    padding: '10px',
                                    border: '1px solid #ddd',
                                    borderRadius: '5px',
                                    fontSize: '16px',
                                    boxSizing: 'border-box'
                                }}
                            >
                                <option value="cliente">Cliente</option>
                                <option value="super-admin">Super Administrador</option>
                                <option value="admin">Administrador</option>
                                <option value="vendedor">Vendedor</option>
                            </select>
                        </div>

                        <div style={{ marginBottom: '20px' }}>
                            <label style={{ 
                                display: 'block', 
                                marginBottom: '5px',
                                fontWeight: 'bold',
                                color: '#333'
                            }}>
                                Estado
                            </label>
                            <select
                                name="estado"
                                value={formData.estado}
                                onChange={handleChange}
                                disabled={loading}
                                style={{
                                    width: '100%',
                                    padding: '10px',
                                    border: '1px solid #ddd',
                                    borderRadius: '5px',
                                    fontSize: '16px',
                                    boxSizing: 'border-box'
                                }}
                            >
                                <option value="activo">Activo</option>
                                <option value="inactivo">Inactivo</option>
                            </select>
                        </div>

                        {/* Botones */}
                        <div style={{ 
                            display: 'flex', 
                            gap: '10px', 
                            justifyContent: 'flex-end',
                            marginTop: '30px'
                        }}>
                            <button
                                type="button"
                                onClick={handleCancel}
                                disabled={loading}
                                style={{
                                    padding: '10px 20px',
                                    border: '2px solid #925c93',
                                    backgroundColor: 'transparent',
                                    color: '#925c93',
                                    borderRadius: '5px',
                                    cursor: loading ? 'not-allowed' : 'pointer',
                                    fontSize: '16px'
                                }}
                            >
                                Cancelar
                            </button>
                            <button
                                type="submit"
                                disabled={loading}
                                style={{
                                    padding: '10px 20px',
                                    border: 'none',
                                    backgroundColor: loading ? '#ccc' : '#b0417a',
                                    color: 'white',
                                    borderRadius: '5px',
                                    cursor: loading ? 'not-allowed' : 'pointer',
                                    fontSize: '16px'
                                }}
                            >
                                {loading ? '🔄 Guardando...' : '💾 Guardar Cambios'}
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </>
    );
}

export default EditarUsuario;