import { Navbar } from '../../components/Navbar/Navbar';
import { Productos } from '../../components/Productos/Productos';

export default function Inventario() {
    return (
        <div className="admin-page">
            <Navbar/>
            <main className="admin-main">
                <div className="admin-dashboard-container">
                    <h1 className="dashboard-title">Gestión de Inventario</h1>
                    <Productos/>
                </div>
            </main>
        </div>
    );
}