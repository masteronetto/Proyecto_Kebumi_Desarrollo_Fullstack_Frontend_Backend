import { Navbar } from '../../components/Navbar/Navbar';
import { Usuarios } from '../../components/Usuarios/Usuarios';

export default function AdminUsuarios() {
    return (
        <div className="admin-page">
            <Navbar/>
            <main className="admin-main">
                <div className="admin-users-container">
                    <h1 className="dashboard-title">Gestión de Usuarios</h1>
                    <Usuarios/>
                </div>
            </main>
        </div>
    );
}