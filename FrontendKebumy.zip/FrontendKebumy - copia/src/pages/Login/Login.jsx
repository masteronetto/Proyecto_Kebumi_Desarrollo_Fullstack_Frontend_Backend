import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import useAuth from '../../hooks/useAuth';
import apiService from '../../services/apiService';
import logoKebumy from '../../assets/logoKebumy.png';
import { BackendToggle } from '../../components/BackendToggle/BackendToggle';

export default function Login() {
    // 1. Estados para el formulario, carga y errores
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [userRole, setUserRole] = useState('super-admin');
    const [error, setError] = useState(null);
    const [loading, setLoading] = useState(false);
    
    // 2. Hook para redirección y autenticación
    const navigate = useNavigate();
    const location = useLocation();
    const { login, isAuthenticated } = useAuth();
    
    // 3. Redirigir si ya está autenticado
    useEffect(() => {
        if (isAuthenticated) {
            // Redirigir al panel de administración por defecto
            const from = location.state?.from?.pathname || '/admin-usuarios';
            navigate(from, { replace: true });
        }
    }, [isAuthenticated, navigate, location]);

    // 4. Lógica principal de autenticación
    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        setError(null);
        
        console.log('🔐 Iniciando proceso de login...');
        
        const credenciales = { 
            email, 
            password,
            role: userRole.toUpperCase()
        };

        try {
            console.log('📤 Enviando credenciales al servicio API...');
            
            // Usar el servicio API para login
            const userData = await apiService.login(credenciales);
            
            console.log('✅ Login exitoso, datos recibidos:', userData);
            console.log('🔍 Estructura de userData:', {
                hasEmail: !!userData?.email,
                hasRole: !!userData?.role,
                hasRol: !!userData?.rol,
                hasToken: !!userData?.token,
                keys: Object.keys(userData || {})
            });
            
            // Usar el hook de autenticación
            const loginSuccess = login(userData);
            
            console.log('🔍 Resultado de login hook:', loginSuccess);
            
            if (loginSuccess) {
                console.log('🎯 Autenticación procesada, redirigiendo...');
                
                // Determinar a dónde redirigir basado en el rol
                let redirectPath = '/admin-usuarios'; // Por defecto, panel de usuarios
                
                if (location.state?.from?.pathname) {
                    redirectPath = location.state.from.pathname;
                } else if (userData.rol === 'super-admin' || userData.role === 'ADMIN') {
                    redirectPath = '/admin-usuarios'; // Panel de gestión de usuarios para admins
                }
                
                console.log('🚀 Redirigiendo a:', redirectPath);
                navigate(redirectPath, { replace: true });
                
            } else {
                throw new Error("Error al procesar la autenticación.");
            }

        } catch (err) {
            console.error('❌ Login Fallido:', err);
            console.error('🔍 Tipo de error:', err.name);
            console.error('🔍 Mensaje completo:', err.message);
            console.error('🔍 Stack trace:', err.stack);
            
            // Diagnóstico específico para backend real
            if (apiService.useRealBackend) {
                console.log('🔧 Diagnóstico Backend Real:');
                console.log('- URL Base:', apiService.baseURL);
                console.log('- Endpoint Login:', apiService.baseURL + '/usuarios/login');
                console.log('- ¿Backend activo?', 'Verifica que el backend esté corriendo en puerto 3000');
            }
            
            setError(err.message || 'Error de conexión. Verifique sus credenciales e inténtelo de nuevo.');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="login-container">
            <div className="login-box">
                {/* Logo de Kebumy */}
                <div style={{ textAlign: 'center', marginBottom: '30px' }}>
                    <img 
                        src={logoKebumy} 
                        alt="Kebumy Logo" 
                        style={{ width: '200px', marginBottom: '20px' }}
                    />
                    <h3 style={{ margin: '0', color: '#555' }}>Panel de Administración</h3>
                </div>
                
                {/* Pestañas de Login */}
                <div className="login-tabs">
                    <div className="login-tab active">
                        Acceso Administrador
                    </div>
                </div>
                
                {/* Muestra el error si existe */}
                {error && (
                    <div style={{ 
                        backgroundColor: '#f8d7da', 
                        color: '#721c24', 
                        padding: '10px', 
                        borderRadius: '5px', 
                        marginBottom: '20px',
                        border: '1px solid #f5c6cb'
                    }}>
                        {error}
                    </div>
                )}
                
                <form onSubmit={handleSubmit}>
                    {/* Selector de Rol */}
                    <div className="login-role-selector">
                        <label htmlFor="userRole">Tipo de Usuario</label>
                        <select
                            id="userRole"
                            value={userRole}
                            onChange={(e) => setUserRole(e.target.value)}
                            disabled={loading}
                        >
                            <option value="super-admin">Super Administrador</option>
                            <option value="vendedor">Vendedor</option>
                        </select>
                    </div>
                    
                    <div className="form-group">
                        <label htmlFor="email">Email</label>
                        <input 
                            type="email" 
                            id="email" 
                            value={email}
                            onChange={(e) => setEmail(e.target.value)} 
                            required 
                            disabled={loading}
                            placeholder="admin@kebumy.com"
                        />
                    </div>
                    
                    <div className="form-group">
                        <label htmlFor="password">Contraseña</label>
                        <input 
                            type="password" 
                            id="password" 
                            value={password}
                            onChange={(e) => setPassword(e.target.value)} 
                            required 
                            disabled={loading}
                            placeholder="Ingrese su contraseña"
                        />
                        <a href="#" className="forgot-password">¿Olvidaste tu contraseña?</a>
                    </div>
                    
                    <button type="submit" className="submit-button" disabled={loading}>
                        {loading ? '🔐 Verificando credenciales...' : '🚀 Ingresar al Panel'}
                    </button>
                    
                    {/* Información de prueba */}
                    <div style={{ 
                        marginTop: '20px', 
                        padding: '10px', 
                        backgroundColor: '#d1ecf1', 
                        borderRadius: '5px',
                        fontSize: '12px',
                        color: '#0c5460'
                    }}>
                        <strong>Credenciales de prueba:</strong><br />
                        Email: admin@kebumy.com<br />
                        Contraseña: admin123
                    </div>
                </form>
            </div>
            
            {/* Herramienta de diagnóstico y cambio de backend */}
            <BackendToggle />
        </div>
    );
}