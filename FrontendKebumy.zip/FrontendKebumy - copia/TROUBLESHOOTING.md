# 🔧 Solución de Problemas de Conexión Backend

## ✅ Verificaciones Básicas

### 1. Verificar que el Backend esté ejecutándose
Abrir en el navegador: [http://localhost:3000/api/health](http://localhost:3000/api/health)

**Respuesta esperada:**
```json
{
  "backend_url": "http://localhost:8081",
  "frontend_url": "http://localhost:5173",
  "timestamp": 1759941579715,
  "message": "Backend is running successfully",
  "status": "OK"
}
```

### 2. Probar Backend Real
Abrir en el navegador: [http://localhost:8081/api/productos](http://localhost:8081/api/productos)

### 3. Verificar endpoints principales
- **Productos:** [http://localhost:8080/api/productos](http://localhost:8080/api/productos)
- **Usuarios:** [http://localhost:8080/api/usuarios](http://localhost:8080/api/usuarios)

## 🛠️ Pasos de Depuración

### Paso 1: Verificar desde el Frontend
1. Ejecutar `npm run dev`
2. Activar el toggle "Usar Backend Real"
3. Hacer clic en "Test" en el panel de backend
4. Revisar la consola del navegador (F12) para ver errores detallados

### Paso 2: Verificar configuración CORS en Backend
Asegurar que el backend tenga configurado:
```java
@CrossOrigin(origins = "http://localhost:5173")
```

### Paso 3: Verificar que MySQL esté corriendo
- MySQL debe estar ejecutándose en puerto 3306
- Base de datos `proyecto_kebumy` debe existir
- Tablas `usuarios` y `productos` deben estar creadas

## 🚨 Errores Comunes y Soluciones

### Error: "Failed to fetch"
**Causa:** Backend no está ejecutándose o puerto incorrecto
**Solución:** 
1. Verificar que Spring Boot esté corriendo en puerto 8080
2. Probar manualmente: `curl http://localhost:8080/api/health`

### Error: "CORS policy"
**Causa:** Configuración CORS incorrecta
**Solución:**
1. Verificar `@CrossOrigin` en los controladores
2. Verificar que CorsConfig permita `http://localhost:5173`

### Error: "Network Error"
**Causa:** Problema de red o configuración de proxy
**Solución:**
1. Deshabilitar antivirus/firewall temporalmente
2. Verificar que no haya proxy configurado

### Error: "404 Not Found"
**Causa:** Endpoints incorrectos
**Solución:**
1. Verificar que los endpoints coincidan entre frontend y backend
2. Verificar que los controladores tengan `@RequestMapping("/api")`

## 📋 Checklist de Verificación

- [ ] ✅ Backend Spring Boot ejecutándose en puerto 8080
- [ ] ✅ MySQL ejecutándose en puerto 3306
- [ ] ✅ Base de datos `proyecto_kebumy` existe
- [ ] ✅ Tablas creadas por el backend
- [ ] ✅ CORS configurado para `http://localhost:5173`
- [ ] ✅ Frontend ejecutándose en puerto 5173
- [ ] ✅ Toggle de backend activado en el frontend
- [ ] ✅ Consola del navegador sin errores

## 🔍 Logs Útiles

### En la Consola del Navegador (F12):
```javascript
// Ver configuración actual
console.log('API Config:', apiService);

// Test manual de conexión
fetch('http://localhost:8080/api/health')
  .then(r => r.json())
  .then(console.log)
  .catch(console.error);
```

### En la Consola del Backend:
- Verificar logs de Spring Boot
- Buscar errores de CORS
- Verificar conexión a MySQL

## 🎯 Próximos Pasos si Todo Falla

1. **Verificar versiones:**
   - Java 17 (no 21)
   - Spring Boot compatible
   - MySQL 8.0+

2. **Reiniciar servicios:**
   ```bash
   # Reiniciar MySQL
   net stop mysql80
   net start mysql80
   
   # Reiniciar backend
   ./mvnw spring-boot:run
   
   # Reiniciar frontend
   npm run dev
   ```

3. **Verificar puertos:**
   ```bash
   netstat -an | findstr :8080
   netstat -an | findstr :5173
   netstat -an | findstr :3306
   ```

---

**💡 Tip:** Si todo falla, usar el modo desarrollo (datos mock) mientras se soluciona el backend. El frontend funcionará perfectamente sin conexión al backend.