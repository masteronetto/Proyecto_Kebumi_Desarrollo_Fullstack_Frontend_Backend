# 🚨 Solución "Failed to Fetch" en Login

## 🔍 **Diagnóstico Paso a Paso**

### **1. Verificar si es problema de modo**
```javascript
// En la consola del navegador (F12):
console.log('Modo actual:', apiService.useRealBackend);
```

**Si está en `false`**: El login debería funcionar con datos mock
**Si está en `true`**: El problema es de conexión con el backend

### **2. Probar login con datos mock PRIMERO**
1. **Desactivar** el toggle "Usar Backend Real"
2. **Login:** `admin@kebumy.com` / `admin_pass`
3. **Resultado esperado:** Debe funcionar sin problemas

### **3. Si funciona en mock, el problema es CORS/Backend**

#### **Verificación manual:**
```javascript
// En consola del navegador (F12):
fetch('http://localhost:8081/api/login', {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
    },
    mode: 'cors',
    body: JSON.stringify({
        email: 'admin@kebumy.com',
        password: 'admin_pass'
    })
})
.then(response => {
    console.log('Status:', response.status);
    console.log('Headers:', [...response.headers.entries()]);
    return response.text();
})
.then(data => console.log('Response:', data))
.catch(error => console.error('Error:', error));
```

### **4. Problemas más comunes y soluciones**

#### **Error: "TypeError: Failed to fetch"**
**Causa:** CORS no configurado o backend no disponible
**Solución:** Verificar backend Spring Boot:

```java
// En tu backend - Agregar configuración CORS
@CrossOrigin(origins = {
    "http://localhost:5173", 
    "http://localhost:5174"  // ← Puerto actual del frontend
})
@PostMapping("/login")
public ResponseEntity<?> login(@RequestBody LoginRequest request) {
    // ... tu lógica de login
}
```

#### **Error: "404 Not Found"**
**Causa:** Endpoint `/api/login` no existe
**Solución:** Verificar que el controlador esté correcto:

```java
@RestController
@RequestMapping("/api")  // ← Importante el /api
public class AuthController {
    
    @PostMapping("/login")  // ← Esto crea /api/login
    public ResponseEntity<?> login(@RequestBody LoginRequest request) {
        // Tu lógica aquí
    }
}
```

#### **Error: "500 Internal Server Error"**
**Causa:** Error en el backend al procesar login
**Solución:** Revisar logs del backend Spring Boot

### **5. Herramienta de Diagnóstico**

1. **Activar modo backend real** en el toggle
2. **Hacer clic en "Diagnóstico Completo"**
3. **Revisar cada paso** que aparece
4. **Identificar dónde falla exactamente**

### **6. URLs que deben funcionar**

Probar en el navegador:
- ✅ Health Check: http://localhost:3000/api/health
- 🔄 Backend: http://localhost:8081/api/usuarios (debe dar error CORS, pero no 404)
- 🔄 Login: Debe aceptar POST en http://localhost:8081/api/login

### **7. Configuración correcta del backend**

Tu backend debe:
```java
// 1. Configuración CORS
@Configuration
public class CorsConfig {
    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration configuration = new CorsConfiguration();
        configuration.setAllowedOrigins(Arrays.asList(
            "http://localhost:5173",
            "http://localhost:5174"
        ));
        configuration.setAllowedMethods(Arrays.asList("GET", "POST", "PUT", "DELETE", "OPTIONS"));
        configuration.setAllowedHeaders(Arrays.asList("*"));
        configuration.setAllowCredentials(true);
        
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", configuration);
        return source;
    }
}

// 2. Controlador de Login
@RestController
@RequestMapping("/api")
@CrossOrigin(origins = {"http://localhost:5173", "http://localhost:5174"})
public class AuthController {
    
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Map<String, String> credentials) {
        String email = credentials.get("email");
        String password = credentials.get("password");
        
        // Tu lógica de autenticación aquí
        if ("admin@kebumy.com".equals(email) && "admin_pass".equals(password)) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            
            Map<String, Object> userData = new HashMap<>();
            userData.put("id", 1);
            userData.put("nombre", "Admin Kebumy");
            userData.put("email", email);
            userData.put("rol", "super-admin");
            userData.put("token", "jwt-token-here");
            
            response.put("data", userData);
            return ResponseEntity.ok(response);
        } else {
            return ResponseEntity.status(401).body(Map.of("success", false, "message", "Credenciales inválidas"));
        }
    }
}
```

## 🎯 **Pasos de Solución Ordenados**

1. ✅ **Probar login mock** (toggle desactivado)
2. 🔍 **Ejecutar diagnóstico completo**
3. 🔧 **Configurar CORS en backend** 
4. 🔄 **Reiniciar backend**
5. ✅ **Probar login real** (toggle activado)

---

**💡 El 95% de "Failed to fetch" se soluciona configurando CORS correctamente en el backend.**