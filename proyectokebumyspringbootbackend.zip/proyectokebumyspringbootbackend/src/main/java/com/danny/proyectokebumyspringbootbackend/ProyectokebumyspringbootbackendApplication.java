package com.danny.proyectokebumyspringbootbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectokebumyspringbootbackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectokebumyspringbootbackendApplication.class, args);
	}

}
