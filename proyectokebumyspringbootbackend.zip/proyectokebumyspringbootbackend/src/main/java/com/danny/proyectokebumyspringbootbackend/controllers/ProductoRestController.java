package com.danny.proyectokebumyspringbootbackend.controllers;
import com.danny.proyectokebumyspringbootbackend.entities.Producto;
import com.danny.proyectokebumyspringbootbackend.services.ProductoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.HashMap;

@RestController
@RequestMapping("/api/productos")
@CrossOrigin(origins = {"http://localhost:5173"})
public class ProductoRestController {
     @Autowired
    private ProductoService productoService;

    
    @PostMapping
    public ResponseEntity<?> crearProducto(@RequestBody Producto producto) {
        try {
            Producto nuevoProducto = productoService.crear(producto);
            return new ResponseEntity<>(nuevoProducto, HttpStatus.CREATED);
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        }
    }

    @GetMapping
    public ResponseEntity<List<Producto>> listarProductos() {
        try {
            System.out.println("=== LISTAR PRODUCTOS ===");
            List<Producto> productos = productoService.listarTodas();
            System.out.println("Productos encontrados: " + productos.size());
            return ResponseEntity.ok(productos);
        } catch (Exception e) {
            System.out.println("Error al listar productos: " + e.getMessage());
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }
    
    
    @GetMapping("/{id}")
    public ResponseEntity<?> obtenerProductoPorId(@PathVariable Long id) {
        try {
            Producto producto = productoService.obtenerId(id);
            return ResponseEntity.ok(producto);
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }

    
    @PutMapping("/{id}")
    public ResponseEntity<?> actualizarProducto(@PathVariable Long id, @RequestBody Producto productoActualizado) {
        try {
            Producto producto = productoService.actualizar(id, productoActualizado);
            return ResponseEntity.ok(producto);
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        }
    }

    
    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminarProducto(@PathVariable Long id) {
        try {
            productoService.eliminar(id);
            return ResponseEntity.noContent().build();
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }
    
    
    @GetMapping("/stock-bajo")
    public ResponseEntity<List<Producto>> obtenerStockBajo() {
      
        List<Producto> productos = productoService.obtenerProductosStockBajo(5);
        return ResponseEntity.ok(productos);
    }
    
    @GetMapping("/test")
    public ResponseEntity<?> testConexion() {
        try {
            System.out.println("=== TEST DE CONEXIÓN ===");
            List<Producto> productos = productoService.listarTodas();
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Conexión exitosa");
            response.put("count", productos.size());
            response.put("productos", productos);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            System.out.println("Error en test de conexión: " + e.getMessage());
            e.printStackTrace();
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "Error de conexión");
            response.put("error", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }
}
