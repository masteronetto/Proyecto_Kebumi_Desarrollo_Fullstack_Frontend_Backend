package com.danny.proyectokebumyspringbootbackend.services;

import java.util.List;

import com.danny.proyectokebumyspringbootbackend.entities.Producto;

public interface ProductoService {

    Producto crear(Producto producto);
    Producto obtenerId(Long id);
    List<Producto> listarTodas();
    void eliminar(Long id);
    Producto actualizar(Long id, Producto productoActualizado);
    List<Producto> obtenerProductosStockBajo(int limite);
}
