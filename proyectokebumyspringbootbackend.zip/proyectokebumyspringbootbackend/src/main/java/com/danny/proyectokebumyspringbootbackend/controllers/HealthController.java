package com.danny.proyectokebumyspringbootbackend.controllers;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = {"http://localhost:5173", "http://localhost:5174"})
public class HealthController {

    @GetMapping("/health")
    public ResponseEntity<?> health() {
        return ResponseEntity.ok(Map.of(
            "status", "OK",
            "message", "Backend is running successfully",
            "timestamp", System.currentTimeMillis(),
            "frontend_url", "http://localhost:5173",
            "backend_url", "http://localhost:3000"
        ));
    }

    @GetMapping("/test-cors")
    public ResponseEntity<?> testCors() {
        return ResponseEntity.ok(Map.of(
            "cors", "enabled",
            "message", "CORS is working correctly",
            "allowed_origins", new String[]{"http://localhost:5173", "http://localhost:5174"},
            "backend_port", 3000,
            "frontend_ports", new int[]{5173, 5174}
        ));
    }
}