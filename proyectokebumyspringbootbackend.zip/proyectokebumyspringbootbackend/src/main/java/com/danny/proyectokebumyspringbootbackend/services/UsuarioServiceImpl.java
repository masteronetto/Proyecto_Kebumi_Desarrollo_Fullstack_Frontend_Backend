package com.danny.proyectokebumyspringbootbackend.services;

import com.danny.proyectokebumyspringbootbackend.entities.Usuario;
import com.danny.proyectokebumyspringbootbackend.repositories.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UsuarioServiceImpl implements UsuarioService {
    @Autowired
    private UsuarioRepository usuarioRepository;

    @Override
    public Usuario crear(Usuario usuario) {
        // Validaciones básicas
        if (usuario.getEmail() == null || usuario.getEmail().trim().isEmpty()) {
            throw new RuntimeException("El email es requerido");
        }
        if (usuario.getPassword() == null || usuario.getPassword().trim().isEmpty()) {
            throw new RuntimeException("La contraseña es requerida");
        }
        
        // Verificar si el email ya existe
        Usuario usuarioExistente = usuarioRepository.findByEmail(usuario.getEmail().trim());
        if (usuarioExistente != null) {
            throw new RuntimeException("Ya existe un usuario con este email");
        }
        
        usuario.setEmail(usuario.getEmail().trim());
        usuario.setRol(usuario.getRol() != null ? usuario.getRol() : "cliente");
        usuario.setEstado(usuario.getEstado() != null ? usuario.getEstado() : "activo");
        
        return usuarioRepository.save(usuario);
    }

    @Override
    public Usuario obtenerId(Long id) {
        return usuarioRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado con ID: " + id));
    }

    @Override
    public List<Usuario> listarTodas() {
        return (List<Usuario>) usuarioRepository.findAll();
    }

    @Override
    public void eliminar(Long id) {
        if (!usuarioRepository.existsById(id)) {
            
            throw new RuntimeException("Usuario no encontrado con ID: " + id);
        }
        usuarioRepository.deleteById(id);
    }

    @Override
    public Usuario actualizar(Long id, Usuario usuarioActualizado) {
        Usuario existente = obtenerId(id);

        
        existente.setNombre(usuarioActualizado.getNombre());
        existente.setEmail(usuarioActualizado.getEmail());
        existente.setRol(usuarioActualizado.getRol());
        existente.setEstado(usuarioActualizado.getEstado());
        
        
        if (usuarioActualizado.getPassword() != null && !usuarioActualizado.getPassword().isEmpty()) {
           
            existente.setPassword(usuarioActualizado.getPassword()); 
        }

        return usuarioRepository.save(existente);
    }

    @Override
    public Usuario validarCredenciales(String email, String password) {
        // Validar entrada
        if (email == null || email.trim().isEmpty() || password == null || password.trim().isEmpty()) {
            return null;
        }
        
        Usuario usuario = usuarioRepository.findByEmail(email.trim());
        if (usuario == null) {
            return null; 
        }
        
        // Verificar contraseña
        if (usuario.getPassword().equals(password)) {
            // Verificar que el usuario esté activo
            if ("activo".equalsIgnoreCase(usuario.getEstado())) {
                return usuario; 
            }
        }
        
        return null; 
    }
}
