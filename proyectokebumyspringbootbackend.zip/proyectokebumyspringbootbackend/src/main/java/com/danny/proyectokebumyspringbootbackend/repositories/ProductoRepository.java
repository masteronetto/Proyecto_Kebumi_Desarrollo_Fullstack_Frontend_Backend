package com.danny.proyectokebumyspringbootbackend.repositories;

import com.danny.proyectokebumyspringbootbackend.entities.Producto;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

public interface ProductoRepository extends CrudRepository<Producto,Long> {
    List<Producto> findByStockLessThan(int limite);
    
}
