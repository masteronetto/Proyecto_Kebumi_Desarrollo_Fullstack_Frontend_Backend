package com.danny.proyectokebumyspringbootbackend.controllers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.danny.proyectokebumyspringbootbackend.entities.Usuario;
import com.danny.proyectokebumyspringbootbackend.services.UsuarioService;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

@RestController
@RequestMapping("/api/usuarios")
@CrossOrigin(origins = {"http://localhost:5173"})
public class UsuarioRestController {

    @Autowired
    private UsuarioService usuarioService;

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Map<String, String> credenciales) {
        try {
            System.out.println("=== LOGIN ATTEMPT ===");
            System.out.println("Credenciales recibidas: " + credenciales);

            String email = credenciales.get("email");
            String password = credenciales.get("password");

            if (email == null || email.trim().isEmpty() || password == null || password.trim().isEmpty()) {
                Map<String, Object> response = new HashMap<>();
                response.put("success", false);
                response.put("message", "Email y contraseña son requeridos");
                response.put("error", "Credenciales incompletas");
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
            }

            Usuario usuarioAutenticado = usuarioService.validarCredenciales(email, password);
            System.out.println("Usuario encontrado: " + (usuarioAutenticado != null));

            if (usuarioAutenticado != null) {
                usuarioAutenticado.setPassword(null);
                Map<String, Object> response = new HashMap<>();
                response.put("success", true);
                response.put("message", "Login exitoso");
                response.put("usuario", usuarioAutenticado);
                return ResponseEntity.ok(response);
            } else {
                Map<String, Object> response = new HashMap<>();
                response.put("success", false);
                response.put("message", "Credenciales inválidas");
                response.put("error", "Usuario o contraseña incorrectos");
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(response);
            }
        } catch (Exception e) {
            System.out.println("Error en login: " + e.getMessage());
            e.printStackTrace();
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "Error interno del servidor");
            response.put("error", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    @PostMapping("/registro")
    public ResponseEntity<?> registrarUsuario(@RequestBody Usuario usuario) {
        try {
            System.out.println("=== REGISTRO ATTEMPT ===");
            System.out.println("Usuario recibido: " + usuario);

            usuario.setRol("cliente");
            Usuario nuevoUsuario = usuarioService.crear(usuario);
            nuevoUsuario.setPassword(null);

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Usuario registrado exitosamente");
            response.put("usuario", nuevoUsuario);

            System.out.println("Usuario creado exitosamente: " + nuevoUsuario.getEmail());
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            System.out.println("Error en registro: " + e.getMessage());
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", e.getMessage());
            response.put("error", e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        }
    }

    @GetMapping
    public ResponseEntity<List<Usuario>> listarUsuarios() {
        try {
            System.out.println("=== LISTAR USUARIOS ===");
            List<Usuario> usuarios = usuarioService.listarTodas();
            usuarios.forEach(u -> u.setPassword(null));
            return ResponseEntity.ok(usuarios);
        } catch (Exception e) {
            System.out.println("Error al listar usuarios: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> obtenerUsuarioPorId(@PathVariable Long id) {
        try {
            Usuario usuario = usuarioService.obtenerId(id);
            usuario.setPassword(null);
            return ResponseEntity.ok(usuario);
        } catch (RuntimeException e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", e.getMessage());
            response.put("error", "Usuario no encontrado");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
        }
    }

    @PostMapping("/admin")
    public ResponseEntity<?> crearUsuarioAdmin(@RequestBody Usuario usuario) {
        try {
            System.out.println("=== CREAR USUARIO (ADMIN) ===");
            System.out.println("Usuario recibido: " + usuario);

            Usuario nuevoUsuario = usuarioService.crear(usuario);
            nuevoUsuario.setPassword(null);

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Usuario creado exitosamente");
            response.put("usuario", nuevoUsuario);

            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        } catch (RuntimeException e) {
            System.out.println("Error al crear usuario: " + e.getMessage());
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", e.getMessage());
            response.put("error", e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> actualizarUsuario(@PathVariable Long id, @RequestBody Usuario usuarioActualizado) {
        try {
            System.out.println("=== ACTUALIZAR USUARIO ===");
            System.out.println("ID: " + id + ", Usuario: " + usuarioActualizado);

            Usuario usuario = usuarioService.actualizar(id, usuarioActualizado);
            usuario.setPassword(null);

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Usuario actualizado exitosamente");
            response.put("usuario", usuario);

            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            System.out.println("Error al actualizar usuario: " + e.getMessage());
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", e.getMessage());
            response.put("error", e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminarUsuario(@PathVariable Long id) {
        try {
            System.out.println("=== ELIMINAR USUARIO ===");
            System.out.println("ID a eliminar: " + id);

            usuarioService.eliminar(id);

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Usuario eliminado exitosamente");

            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            System.out.println("Error al eliminar usuario: " + e.getMessage());
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", e.getMessage());
            response.put("error", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
        }
    }
}
