package com.danny.proyectokebumyspringbootbackend.services;

import org.springframework.beans.factory.annotation.Autowired;

import com.danny.proyectokebumyspringbootbackend.entities.Producto;
import com.danny.proyectokebumyspringbootbackend.repositories.ProductoRepository;
import java.math.BigDecimal;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class ProductoServiceImpl implements ProductoService {

 @Autowired
    private ProductoRepository productoRepository;

    @Override
    public Producto crear(Producto producto) {
        // Validaciones básicas
        if (producto.getNombre() == null || producto.getNombre().trim().isEmpty()) {
            throw new RuntimeException("El nombre del producto es requerido");
        }
        if (producto.getPrecio() == null || producto.getPrecio().compareTo(BigDecimal.ZERO) <= 0) {
            throw new RuntimeException("El precio debe ser mayor a cero");
        }
        if (producto.getStock() < 0) {
            throw new RuntimeException("El stock no puede ser negativo");
        }
        
        return productoRepository.save(producto);
    }

    @Override
    public Producto obtenerId(Long id) {
        return productoRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Producto no encontrado con ID: " + id));
    }

    @Override
    public List<Producto> listarTodas() {
        try {
            System.out.println("=== SERVICIO: LISTANDO PRODUCTOS ===");
            List<Producto> productos = (List<Producto>) productoRepository.findAll();
            System.out.println("Productos recuperados de la BD: " + productos.size());
            return productos;
        } catch (Exception e) {
            System.out.println("Error en ProductoService.listarTodas(): " + e.getMessage());
            e.printStackTrace();
            throw new RuntimeException("Error al acceder a la base de datos: " + e.getMessage());
        }
    }

    @Override
    public void eliminar(Long id) {
        if (!productoRepository.existsById(id)) {
            throw new RuntimeException("Producto no encontrado con ID: " + id);
        }
        productoRepository.deleteById(id);
    }

    @Override
    public Producto actualizar(Long id, Producto productoActualizado) {
        Producto existente = obtenerId(id);
        
        // Actualizar campos esenciales
        existente.setNombre(productoActualizado.getNombre());
        existente.setDescripcion(productoActualizado.getDescripcion());
        existente.setPrecio(productoActualizado.getPrecio());
        existente.setStock(productoActualizado.getStock());
        existente.setCategoriaNombre(productoActualizado.getCategoriaNombre());
        existente.setImagenUrl(productoActualizado.getImagenUrl());
        existente.setEstado(productoActualizado.getEstado());

        return productoRepository.save(existente);
    }
    
    @Override
    public List<Producto> obtenerProductosStockBajo(int limite) {
        
        return productoRepository.findByStockLessThan(limite);
    }
}
