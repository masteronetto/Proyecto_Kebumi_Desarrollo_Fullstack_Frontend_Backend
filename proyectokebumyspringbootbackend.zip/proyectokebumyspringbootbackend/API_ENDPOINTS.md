# API Endpoints - Backend Spring Boot

## Base URL
```
http://localhost:3000
```

## Endpoints disponibles

### 🔍 **Health Check & Testing**
- `GET /api/health` - Verificar que el backend esté funcionando
- `GET /api/test-cors` - Verificar configuración CORS

### 👤 **Usuarios**
- `POST /api/usuarios/login` - Iniciar sesión
- `POST /api/usuarios/registro` - Registrar nuevo usuario (cliente)
- `GET /api/usuarios` - Listar todos los usuarios
- `POST /api/usuarios` - Crear usuario (admin)
- `PUT /api/usuarios/{id}` - Actualizar usuario
- `DELETE /api/usuarios/{id}` - Eliminar usuario

### 📦 **Productos**
- `GET /api/productos` - Listar todos los productos
- `GET /api/productos/{id}` - Obtener producto por ID
- `POST /api/productos` - Crear nuevo producto
- `PUT /api/productos/{id}` - Actualizar producto
- `DELETE /api/productos/{id}` - Eliminar producto
- `GET /api/productos/stock-bajo` - Productos con stock bajo

## Ejemplos de uso desde el frontend

### Login
```javascript
const response = await fetch('http://localhost:3000/api/usuarios/login', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
  },
  body: JSON.stringify({
    email: 'usuario@email.com',
    password: 'password123'
  })
});
```

### Registro
```javascript
const response = await fetch('http://localhost:3000/api/usuarios/registro', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
  },
  body: JSON.stringify({
    nombre: 'Nombre Usuario',
    email: 'usuario@email.com',
    password: 'password123'
  })
});
```

### Listar productos
```javascript
const response = await fetch('http://localhost:3000/api/productos', {
  method: 'GET',
  headers: {
    'Content-Type': 'application/json',
  }
});
```

### Crear producto
```javascript
const response = await fetch('http://localhost:3000/api/productos', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
  },
  body: JSON.stringify({
    nombre: 'Producto Ejemplo',
    descripcion: 'Descripción del producto',
    precio: 99.99,
    stock: 50,
    categoriaNombre: 'Categoría',
    imagenUrl: 'http://ejemplo.com/imagen.jpg'
  })
});
```

## ⚙️ Configuración CORS
- ✅ Configurado para permitir conexiones desde `http://localhost:5173` y `http://localhost:5174`
- ✅ Métodos permitidos: GET, POST, PUT, DELETE, OPTIONS
- ✅ Headers permitidos: Todos (*)
- ✅ Credenciales permitidas

## 🛠️ Configuración completada
1. ✅ CORS configurado globalmente para ambos puertos del frontend
2. ✅ Manejo de errores mejorado
3. ✅ Endpoints de authentication optimizados
4. ✅ Validaciones añadidas
5. ✅ Formato JSON consistente en respuestas
6. ✅ Puerto 3000 configurado
7. ✅ Base de datos MySQL configurada

## 🚀 Para probar la conexión
1. Asegúrate de que MySQL esté ejecutándose
2. Verifica que la base de datos `proyecto_kebumy` exista
3. El backend debería estar ejecutándose en `http://localhost:3000`
4. Prueba el endpoint: `GET http://localhost:3000/api/health`
5. Frontend funcionando en: `http://localhost:5174`